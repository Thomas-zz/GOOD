// 引用百度地图微信小程序JSAPI模块 
var bmap = require('../../libs/bmap-wx.js');
var wxMarkerData = [];
Page({
  data: {
    markers: [],
    latitude: '',
    longitude: '',
    rgcData: {}
  },
  onLoad: function () {
    var that = this;
    // 新建百度地图对象 
    var BMap = new bmap.BMapWX({
      ak: '6O6R4LtOALop34W4QwaLNP8D9rPmMVFF',
    });
    var fail = function (data) {
      console.log(data)
    };
    var success = function (data) {
      wxMarkerData = data.wxMarkerData;
      that.setData({
        markers: wxMarkerData
      });
      that.setData({
        latitude: wxMarkerData[0].latitude
      });
      that.setData({
        longitude: wxMarkerData[0].longitude
      });
    }
    // 发起geocoding检索请求 
    BMap.geocoding({
      address: "广东省东莞市",
      fail: fail,
      success: success,
      iconPath: '../../img/tab_liliang_icon_default.png',
      iconTapPath: '../../img/tab_me_icon_default.png'
    });
  },
})