// pages/index3/index.js
Page({

  data: {
    region:'选择省/市/区',
    now:''
  },
  selected:function(e){
   this.setData({
    region:e.detail.value
   })
   this.getWeather();
  },
  getWeather:function(){
   var that=this;
   wx.request({
     url: 'https://free-api.heweather.net/s6/weather/now?',
     data:{
       location:that.data.region[1],
       key:'ab2794e5e06e4c22bfc3a4cfd50e6783'
     },
     success:function(res){
        console.log(res.data)
        that.setData({now:res.data.HeWeather6[0].now})
     }
   })
  },

  onLoad: function (options) {

  },


  onReady: function () {

  },

  
  onShow: function () {

  },

  
  onHide: function () {

  },

  
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})