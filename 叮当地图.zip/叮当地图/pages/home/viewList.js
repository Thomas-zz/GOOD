'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '栅格布局',
      items: [{ title: '栅格布局：row && col', link: '/pages/componentDemo/row' }, { title: '栅格布局综合', link: '/pages/componentDemo/rowImg' }]
    }, {
      title: '栅格列表',
      items: [{ title: '栅格列表：row-list', link: '/pages/componentDemo/rowList' }]
    }, {
      title: '位置固定容器 fixed-view',
      items: [{ title: '基本使用', link: '/pages/componentDemo/fixedView' }, { title: '应用案例', link: '/pages/componentDemo/fixedView2' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});