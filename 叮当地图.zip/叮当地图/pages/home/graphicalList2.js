'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '时间轴 timeline',
      items: [{ title: '竖向时间轴', link: '/pages/componentDemo/timeline' }, { title: '横向时间轴', link: '/pages/componentDemo/timeline2' }, { title: '时间轴综合', link: '/pages/componentDemo/timeline3' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});