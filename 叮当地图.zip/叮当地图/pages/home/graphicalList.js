'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '图形与交互',
      items: [{ title: '角标 badge', link: '/pages/componentDemo/badge' }, { title: '分隔符 divider', link: '/pages/componentDemo/divider' }, { title: '星级评价 star', link: '/pages/componentDemo/star' }, { title: '星级展示 mini-star', link: '/pages/componentDemo/miniStar' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});