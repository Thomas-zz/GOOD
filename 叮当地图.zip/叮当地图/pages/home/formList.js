'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '手势类',
      items: [{ title: '按钮 button(官方)', link: '/pages/componentDemo/button' }, { title: '滑动条 slider', link: '/pages/componentDemo/slider' }, { title: '标尺 ruler', link: '/pages/componentDemo/ruler' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});