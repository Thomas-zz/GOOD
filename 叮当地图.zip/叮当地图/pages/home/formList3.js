'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '选择类',
      items: [{ title: '选择列表 check-list', link: '/pages/componentDemo/checklist' }, { title: '数字选择器 stepper', link: '/pages/componentDemo/stepper' }, { title: '级联选择器 cascader', link: '/pages/componentDemo/cascader' }, { title: '索引选择器 index-list', link: '/pages/componentDemo/indexList' }, { title: '日历 calendar', link: '/pages/componentDemo/calendar' }, { title: '纵向日历 v-calendar', link: '/pages/componentDemo/calendar2' }, { title: '周日历 w-calendar', link: '/pages/componentDemo/calendar3' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});