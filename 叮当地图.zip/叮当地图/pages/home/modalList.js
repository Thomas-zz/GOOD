'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '背景遮罩 mask',
      items: [{ title: '基本使用', link: '/pages/componentDemo/mask/mask' }, { title: '图标导航', link: '/pages/componentDemo/mask/iconNav' }, { title: '弹出式提示', link: '/pages/componentDemo/mask/maskTip' }, { title: '操作引导', link: '/pages/componentDemo/mask/maskGuide' }]
    }, {
      title: '模态层 popup',
      items: [{ title: '基本使用', link: '/pages/componentDemo/popup' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});