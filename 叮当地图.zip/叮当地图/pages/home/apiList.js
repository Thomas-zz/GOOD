'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '交互反馈',
      items: [{ title: '获取静态常量', link: '/pages/componentDemo/constant' }, { title: '警告框-Alert', link: '/pages/componentDemo/showAlert' }, { title: '确认框-Confirm', link: '/pages/componentDemo/showConfirm' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});