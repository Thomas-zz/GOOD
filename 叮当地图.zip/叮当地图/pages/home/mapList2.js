'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '天气服务',
      items: [{ title: '所在地天气', link: '../weather/index2' },{title:'查询天气',link:'../index3/index'}]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});