'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '吸顶容器 sticky',
      items: [{ title: '基本使用', link: '/pages/componentDemo/sticky' }, { title: '多个吸顶容器共用', link: '/pages/componentDemo/sticky2' }, { title: '应用案例', link: '/pages/componentDemo/sticky3' }, { title: 'sticky和tabs共用', link: '/pages/componentDemo/sticky4' }]
    }, {
      title: '滑动菜单容器 swipe-out',
      items: [{ title: '基本使用', link: '/pages/componentDemo/swipeOut' }]
    }, {
      title: '折叠面板 accordion',
      items: [{
        title: '基本使用',
        link: '/pages/componentDemo/accordion'
      }]
    }, {
      title: '概要 summary',
      items: [{ title: '基本使用',
        link: '/pages/componentDemo/summary'
      }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});