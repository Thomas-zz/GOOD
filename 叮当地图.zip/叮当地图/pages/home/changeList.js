'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '轮播 swiper(官方)',
      items: [{ title: '自定义样式', link: '/pages/componentDemo/swiper' }]
    }, {
      title: '横向选项卡 tabs',
      items: [{ title: '自定义样式', link: '/pages/componentDemo/tabs' }, { title: '全局tabs', link: '/pages/componentDemo/tabs2' }, { title: '内容共用一个容器', link: '/pages/componentDemo/tabs3' }]
    }, {
      title: '纵向选项卡 v-tabs',
      items: [{ title: '内容共用一个容器(商品分类)', link: '/pages/componentDemo/vtabs' }]
    }, {
      title: '分段式选项卡 segment',
      items: [{ title: '基本使用', link: '/pages/componentDemo/segment' }, { title: '全局segment', link: '/pages/componentDemo/segment2' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});