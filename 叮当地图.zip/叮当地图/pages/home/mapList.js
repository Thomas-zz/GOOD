'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '地图服务',
      items: [{ title: '规则筛选', link: '/pages/componentDemo/mapsdk/mapScreening' }, { title: '搜索位置并查看经纬度', link: '/pages/componentDemo/mapsdk/mapSearchTips' }, { title: '获取位置并查看', link: '/pages/componentDemo/map/getLocation' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});