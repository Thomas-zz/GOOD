'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '图标 icon',
      items: [{ title: '图标库', link: '/pages/componentDemo/icon' }]
    }, {
      title: '朦胧图 blur',
      items: [{ title: '基本使用', link: '/pages/componentDemo/blur' }, { title: '个人中心', link: '/pages/componentDemo/blur3' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});