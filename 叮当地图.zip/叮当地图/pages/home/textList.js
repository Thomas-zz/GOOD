'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    groups: [{
      title: '文本',
      items: [{ title: '标签组 tags', link: '/pages/componentDemo/tags' }, { title: '数字动画 count-up', link: '/pages/componentDemo/countUp' }, { title: '倒计时 count-down', link: '/pages/componentDemo/countDown' }, { title: '滚动公告 roller', link: '/pages/componentDemo/roller' }]
    }]
  },
  navigator: function navigator(e) {
    console.log(e);
    var link = e.currentTarget.dataset.link;
    wx.navigateTo({
      url: link
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});