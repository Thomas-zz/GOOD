'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
// 引用百度地图微信小程序JSAPI模块 
var bmap = require('../../libs/bmap-wx.js');
Page({
  data: {
    weatherData: '',
    city: '',
    pm: '',
    date: '',
    weather: '',
    temperature: '',
    wind: '',
  },
  onLoad: function () {
    var that = this;
    // 新建百度地图对象 
    var BMap = new bmap.BMapWX({
      ak: '6O6R4LtOALop34W4QwaLNP8D9rPmMVFF'
    });
    var fail = function (data) {
      console.log(data)
    };
    var success = function (data) {
      var weatherData = data.currentWeather[0];
      var city;
      var pm;
      var date;
      var temperature;
      var wind;
      var weather;
      city = weatherData.currentCity;
      pm = weatherData.pm25;
      date = weatherData.date;
      temperature = weatherData.temperature;
      wind = weatherData.wind;
      weather = weatherData.weatherDesc;
      /*weatherData = '城市：' + weatherData.currentCity + '\n' + 'PM2.5：' + weatherData.pm25 + '\n' +'日期：' + weatherData.date + '\n' + '温度：' + weatherData.temperature + '\n' +'天气：' + weatherData.weatherDesc + '\n' +'风力：' + weatherData.wind + '\n'; */
      that.setData({
        city: city,
        //weatherData: weatherData 
        pm: pm,
        date: date,
        temperature: temperature,
        wind: wind,
        weather: weather,
        weatherData: weatherData,
      });
    }
    BMap.weather({
      fail: fail,
      success: success
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
})