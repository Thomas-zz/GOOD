"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var items = [];
for (var i = 1; i <= 100; i++) {
  items.push("\u5217\u8868\u9879\u76EE" + i);
}

exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    items: items
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});