'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var bmap = require('../../../static/map/bmap-wx.js');
var wxMarkerData = [];
exports.default = Page({

  data: {
    markers: [],
    latitude: '',
    longitude: '',
    rgcData: {},
    address: ''
  },
  onLoad: function onLoad(e) {
    var that = this;
    // 新建百度地图对象 
    var BMap = new bmap.BMapWX({
      ak: '6O6R4LtOALop34W4QwaLNP8D9rPmMVFF'
    });
    var fail = function fail(data) {
      console.log(data);
    };
    var success = function success(data) {
      wxMarkerData = data.wxMarkerData;
      that.setData({
        markers: wxMarkerData
      });
      that.setData({
        latitude: wxMarkerData[0].latitude
      });
      that.setData({
        longitude: wxMarkerData[0].longitude
      });
      that.setData({
        address: e.address
      });
    };
    // 发起geocoding检索请求 
    BMap.geocoding({
      address: e.address,
      fail: fail,
      success: success,
      iconPath: '../../../images/定位 (1).png',
      iconTapPath: '../../../images/marker.png'
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});