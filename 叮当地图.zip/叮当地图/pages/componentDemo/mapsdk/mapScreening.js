"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    scale: 6,
    latitude: "",
    longitude: "",
    basic: "",
    region: ['北京', '石家庄', '沈阳', '哈尔滨', '杭州', '福州', '济南', '广州', '武汉', '成都', '昆明', '兰州', '台北', '南宁', '银川', '太原', '长春', '南京', '合肥', '南昌', '郑州', '长沙', '海口', '贵阳', '西安', '西宁', '呼和浩特', '拉萨', '乌鲁木齐'],
    city: ['广州市', '深圳市', '珠海市', '汕头市', '佛山市', '韶关市', '湛江市', '肇庆市', '江门市', '茂名市', '惠州市', '梅州市', '汕尾市', '河源市', '阳江市', '清远市', '东莞市', '中山市', '潮州市', '揭阳市', '云浮市'],
    markers: []
  },
  controltap: function controltap(e) {
    var mpCtx = wx.createMapContext("myMap");
    mpCtx.moveToLocation();
    var that = this;
    //  wx.showLoading({
    //     title:"定位中",
    //     mask:true
    //  })
    wx.getLocation({
      type: 'wgs84', // 默认为 wgs84 返回 gps 坐标，gcj02 返回可用于 wx.openLocation 的坐标
      success: function success(res) {
        that.setData({
          latitude: res.latitude, //经度
          longitude: res.longitude, //纬度
          scale: 18,
          markers: [{
            id: 1,
            latitude: res.latitude,
            longitude: res.longitude,
            iconPath: '../../../images/定位icon-54.png',
            width: 50,
            height: 50,
            callout: {
              content: "您当前的位置\n经度:" + res.longitude + "\n纬度:" + res.latitude,
              color: "white",
              bgColor: "#0cc8fe",
              display: 'ALWAYS',
              fontSize: 15,
              borderRadius: 10,
              padding: 8,
              boxShadow: '4px 8px 16px 0 rgba(0)'
            }
          }]
        });
      },
      fail: function fail() {
        // fail
      },
      complete: function complete() {
        // complete
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  // locationMyaddress:function(){
  //   let mpCtx = wx.createMapContext("myMap");
  //    mpCtx.moveToLocation();
  // },
  onLoad: function onLoad(options) {
    var that = this;
    that.mapCtx = wx.createMapContext('myMap');
    wx.getLocation({
      type: 'wgs84',
      success: function success(res) {
        that.setData({
          latitude: res.latitude,
          longitude: res.longitude,
          scale: 7,
          markers: [{
            id: 1,
            latitude: res.latitude,
            longitude: res.longitude,
            iconPath: '../../../images/定位 (1).png',
            width: 50,
            height: 50
          }]
        });
      }
    });
  },
  markFactory: function markFactory(lat, lon, i) {
    //插入标记
    var that = this;
    var markers = this.data.markers;
    var marker = {
      id: i,
      latitude: lat,
      longitude: lon,
      iconPath: '../../../images/528714797040838788.png',
      width: 50,
      height: 50

    };

    markers.push(marker);
    that.setData({
      scale: 5,
      markers: markers
    });
  },
  flagAction: function flagAction() {
    //实现省会地图标记
    var that = this;
    for (var i = 0; i < that.data.city.length; i++) {
      that.setData({
        markers: [{
          id: i
        }]

      });
    }
    for (var i = 0; i < that.data.region.length; i++) {
      wx.request({
        url: 'https://free-api.heweather.net/s6/weather/now?',
        data: {

          location: that.data.region[i], //根据地址获取当地信息
          key: '61ec926d11314a7099ac83de4e2c5d29'
        },
        success: function success(res) {
          var latitude = res.data.HeWeather6[0].basic.lat;
          var longitude = res.data.HeWeather6[0].basic.lon;
          console.log(res.data);
          that.markFactory(latitude, longitude, i);
        },
        fail: function fail() {
          // fail
        },
        complete: function complete() {
          // complete
        }
      });
    }
  },
  temperReaction: function temperReaction() {
    var that = this;
    for (var i = 0; i < that.data.region.length; i++) {
      that.setData({
        markers: [{
          id: i
        }]
      });
    }
    for (var i = 0; i < that.data.city.length; i++) {
      wx.request({
        url: 'https://free-api.heweather.net/s6/weather/now?',
        data: {

          location: that.data.city[i], //根据地址获取当地信息
          key: '61ec926d11314a7099ac83de4e2c5d29'
        },
        success: function success(res) {
          var latitude = res.data.HeWeather6[0].basic.lat;
          var longitude = res.data.HeWeather6[0].basic.lon;
          var temp = res.data.HeWeather6[0].now.tmp;
          console.log(res.data);
          that.markShow(latitude, longitude, i, temp);
        },
        fail: function fail() {
          // fail
        },
        complete: function complete() {
          // complete
        }
      });
    }
  },
  markShow: function markShow(lat, lon, i, temp) {
    var markers = this.data.markers;
    var marker = {
      id: i,
      latitude: lat,
      longitude: lon,
      iconPath: '../../../images/604462165001411939.png',
      width: 50,
      height: 50,
      callout: {
        content: '温度:' + temp + "℃",
        color: "white",
        bgColor: "#4ec1ff",
        display: 'ALWAYS',
        fontSize: 12,
        borderRadius: 10,
        boxShadow: '4px 8px 16px 0 rgba(0)'
      }
    };
    if (temp >= 15) {
      markers.push(marker);
      this.setData({
        scale: 7,
        markers: markers
      });
    }
  },
  airJudement: function airJudement() {
    var that = this;
    for (var i = 0; i < that.data.region.length; i++) {
      that.setData({
        markers: [{
          id: i
        }]
      });
    }
    for (var i = 0; i < that.data.city.length; i++) {
      wx.request({
        url: 'https://free-api.heweather.net/s6/weather/now?',
        data: {

          location: that.data.city[i], //根据地址获取当地信息
          key: '61ec926d11314a7099ac83de4e2c5d29'
        },
        success: function success(res) {
          var latitude = res.data.HeWeather6[0].basic.lat;
          var longitude = res.data.HeWeather6[0].basic.lon;
          var temp = res.data.HeWeather6[0].now.tmp;
          console.log(res.data);
          that.markShow(latitude, longitude, i, temp);
        },
        fail: function fail() {
          // fail
        },
        complete: function complete() {
          // complete
        }
      });
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});