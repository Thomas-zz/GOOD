"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _data;

var _amapWx = require("../../../static/map/amap-wx.js");

var _amapWx2 = _interopRequireDefault(_amapWx);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var key = '4216f7d550dc95ef4ac91e3c0ee6a19a';
exports.default = Page({
  data: (_data = {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    mapHeight: wx.DEFAULT_CONTENT_HEIGHT - 35 + 'px',
    latitude: 39.973700,
    longitude: 116.470528,
    // scale: 16,
    showLocation: true,
    mapCtx: null,
    myAmapFun: null,
    polyline: [],
    markers: [{
      id: 0,
      latitude: 39.989643,
      longitude: 116.481028,
      iconPath: '/images/mapicon_navi_s.png',
      width: 24,
      height: 34
    }, {
      id: 1,
      latitude: 39.90816,
      longitude: 116.434446,
      iconPath: '/images/mapicon_navi_e.png',
      width: 24,
      height: 34
    }],
    includePoints: []
  }, _defineProperty(_data, "polyline", []), _defineProperty(_data, "distance", 0), _defineProperty(_data, "cost", 0.00), _defineProperty(_data, "height", wx.DEFAULT_CONTENT_HEIGHT), _data),
  onLoad: function onLoad() {
    this.initView();
  },
  onReady: function onReady() {
    this.mapCtx = wx.createMapContext('map');
    this.myAmapFun = new _amapWx2.default.AMapWX({ key: key });
    this.initView();
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  walkNav: function walkNav() {
    var _this = this;

    this.initView();
    this.myAmapFun.getWalkingRoute({
      origin: '116.481028,39.989643',
      destination: '116.434446,39.90816',
      success: function success(data) {
        _this.drawLine(data, 'steps');
      },
      fail: function fail(info) {}
    });
  },
  driveNav: function driveNav() {
    var _this2 = this;

    this.initView();
    this.myAmapFun.getDrivingRoute({
      origin: '116.481028,39.989643',
      destination: '116.434446,39.90816',
      success: function success(data) {
        _this2.drawLine(data, 'steps');
      },
      fail: function fail(info) {}
    });
  },
  ridingNav: function ridingNav() {
    var _this3 = this;

    this.initView();
    this.myAmapFun.getRidingRoute({
      origin: '116.481028,39.989643',
      destination: '116.434446,39.90816',
      success: function success(data) {
        _this3.drawLine(data, 'steps');
      },
      fail: function fail(info) {}
    });
  },
  transitNav: function transitNav() {
    var _this4 = this;

    this.initView();
    this.myAmapFun.getTransitRoute({
      origin: '116.481028,39.989643',
      destination: '116.434446,39.90816',
      city: '北京',
      success: function success(data) {
        _this4.setData({
          distance: data.distance,
          cost: parseFloat(data.taxi_cost).toFixed(2)
        });
      },
      fail: function fail(info) {}
    });
  },
  drawLine: function drawLine(data, styles) {
    console.log(data, styles);
    var points = [];
    if (data.paths && data.paths[0] && data.paths[0][styles]) {
      this.setData({
        distance: data.paths[0].distance,
        cost: 0.00
      });
      console.log(this.data.distance, this.data.cost);
      var steps = data.paths[0][styles];
      steps.forEach(function (item, index) {
        var polen = item.polyline.split(';');

        polen.forEach(function (item_, index_) {
          points.push({
            longitude: parseFloat(item_.split(',')[0]),
            latitude: parseFloat(item_.split(',')[1])
          });
        });
      });
    }
    this.setData({
      polyline: [{
        points: points,
        color: '#0091ff',
        width: 5
      }]
    });
    console.log(this.data.polyline);
  },
  initView: function initView() {
    this.setData({
      includePoints: [{
        latitude: 39.989643,
        longitude: 116.481028
      }, {
        latitude: 39.90816,
        longitude: 116.434446
      }]
    });
  }
});