'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _amapWx = require('../../../static/map/amap-wx.js');

var _amapWx2 = _interopRequireDefault(_amapWx);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var key = '4216f7d550dc95ef4ac91e3c0ee6a19a'; // mapComprehensive.js

var icon = '/images/ic_map_mode.png',
    iconActive = '/images/ic_map_mode_active.png';

exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    src: '/images/shop-1.png',
    markers: [{
      id: 1,
      latitude: 39.855745,
      longitude: 116.368432,
      iconPath: iconActive,
      width: 23,
      height: 30
    }, {
      id: 2,
      latitude: 39.867277,
      longitude: 116.368475,
      iconPath: icon,
      width: 23,
      height: 30
    }, {
      id: 3,
      latitude: 39.857755,
      longitude: 116.364870,
      iconPath: icon,
      width: 23,
      height: 30
    }, {
      id: 4,
      latitude: 39.851907,
      longitude: 116.376114,
      iconPath: icon,
      width: 23,
      height: 30
    }, {
      id: 5,
      latitude: 39.863898,
      longitude: 116.375256,
      iconPath: icon,
      width: 23,
      height: 30
    }],
    latitude: 39.855745,
    longitude: 116.368432,
    textData: {},
    controls: [{
      id: 0, // 设置当前控件id,且唯一
      iconPath: '/images/location.png',
      clickable: true,
      position: {
        left: 15,
        top: 450,
        width: 64,
        height: 64
      }
    }],
    city: '',
    starData: [],
    mapHeight: wx.DEFAULT_CONTENT_HEIGHT + 'px',
    height: wx.DEFAULT_CONTENT_HEIGHT
  },
  onReady: function onReady() {
    var obj = {
      latitude: 39.855745,
      longitude: 116.368432
    };
    this.reserveAddr(obj);
  },

  // 标记点markers点击事件
  makertap: function makertap(e) {
    console.log(e);
    var markerId = e.markerId;
    // 执行标记点活动事件
    this.markerActive(markerId);
    // 执行更新信息事件
    this.infoChange(markerId);
  },

  // 标记点活动事件
  markerActive: function markerActive(id) {
    // 遍历marker数组若每一项的id与传过来的参数id相等  那么将该项的图标变为活动状态
    var a = this.data.markers.map(function (item, index) {
      return item.id === id ? {
        id: item.id,
        latitude: item.latitude,
        longitude: item.longitude,
        iconPath: iconActive,
        width: item.width,
        height: item.height
      } : {
        id: item.id,
        latitude: item.latitude,
        longitude: item.longitude,
        iconPath: icon,
        width: item.width,
        height: item.height
      };
    });
    this.setData({
      markers: a
    });
  },

  // 更新信息事件
  infoChange: function infoChange(id) {
    var current = this.data.markers.filter(function (item, index) {
      return item.id === id;
    })[0];
    this.reserveAddr(current);
  },
  reserveAddr: function reserveAddr(markerObj) {
    var _this = this;

    // 调用amapFile.AMapWX构造函数创建myAmapFun实例
    var myAmapFun = new _amapWx2.default.AMapWX({ key: key });
    // 根据参数的坐标值,调用getRegeo方法逆解析地址
    myAmapFun.getRegeo({
      location: markerObj.longitude + ',' + markerObj.latitude,
      success: function success(data) {
        // 调用成功则将相关数据存储至textData
        _this.setData({
          textData: {
            name: data[0].regeocodeData.formatted_address,
            address: data[0].name,
            latitude: data[0].latitude,
            longitude: data[0].longitude
          }
        });
      }
    });
  },

  // 点击文本详情跳转本机地图查看事件
  open: function open() {
    // 调用ui.openLocation方法打开本机地图查看
    wx.openLocation({
      backgroundColor: '#fff',
      color: '#000',
      longitude: Number(this.data.textData.longitude),
      latitude: Number(this.data.textData.latitude),
      name: this.data.textData.name,
      address: this.data.textData.address,
      scale: 16
    });
  },
  controltap: function controltap(e) {
    var mapCtx = wx.createMapContext('map');
    if (e.controlId === 0) {
      // 调用获取的map对象的移动地图中心点到定位点方法
      mapCtx.moveToLocation();
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});