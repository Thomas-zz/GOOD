"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// timeline2.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    list: [{ pos: '上海市', content: '已发货' }, { content: '运输中' }, { content: '派件中' }, { pos: '北京市', content: '已签收' }],
    left: (wx.WIN_WIDTH - 280) / 2,
    winWidth: wx.WIN_WIDTH,
    color: '',
    thisIndex: 0
  },
  Next: function Next() {
    console.log('next');
    if (this.data.thisIndex !== this.data.list.length - 1) {
      this.data.thisIndex++;
      this.setData({
        thisIndex: this.data.thisIndex++
      });
    } else {
      this.data.thisIndex = 0;
      this.setData({
        thisIndex: 0
      });
    }
  },
  Previous: function Previous() {
    if (this.data.thisIndex !== 0) {
      this.data.thisIndex--;
      this.setData({
        thisIndex: this.data.thisIndex--
      });
    } else {
      this.data.thisIndex = this.data.list.length - 1;
      this.setData({
        thisIndex: this.data.list.length - 1
      });
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});