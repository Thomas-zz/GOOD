"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// roller.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    imgSrc: 'http://images.uileader.com/20180413/724c6ad5-b6e0-4971-adeb-f4f502c7243e.png',
    imgSrc2: 'http://images.uileader.com/20180413/71ed499e-df2f-4bfd-9270-eed0171fa752.png',
    Notify: []
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  rollerData: function rollerData() {
    this.data.Notify = [{ "title": "商城即将上线1" }, { "title": "商城即将上线2" }, { "title": "商城即将上线3" }];
    console.log(this.data.Notify);
    this.setData({
      Notify: this.data.Notify
    });
  }
});