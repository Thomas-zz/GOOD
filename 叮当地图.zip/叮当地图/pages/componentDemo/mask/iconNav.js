"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// circleMenu4.js
exports.default = Page({
  data: {
    STATUS_BAR_HEIGHT: wx.STATUS_BAR_HEIGHT,
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    showMask: false,
    rotate1: '',
    rotate2: '',
    rotate3: '',
    switch: false,
    height: wx.DEFAULT_CONTENT_HEIGHT + 'px',
    customStyle1: {
      'background-color': 'rgba(255, 255, 255, 0.8)'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  handleShowMask: function handleShowMask() {
    this.setData({
      showMask: true
    });
  }
});