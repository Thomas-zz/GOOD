"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// mask.js
exports.default = Page({
  data: {
    height: wx.WIN_HEIGHT,
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    top2: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT,
    showMask1: false,
    showMask2: false,
    showMask3: false,
    showMask4: false,
    showMask5: false,
    showMask6: false,
    showMask7: false,
    showMask8: false,
    showMask9: false,
    showMask10: false,
    imgSrc1: 'http://images.uileader.com/20180315/da626bbd-4a86-4d5d-9690-00350528d91f.png',
    customStyle1: {
      'background-color': 'rgba(255, 255, 255, 0.8)'
    },
    customStyle2: {
      'background-color': 'rgba(255, 255, 255, 0)'
    }
  },
  masktap: function masktap(e) {
    console.log(e);
  },
  handleTap: function handleTap() {
    wx.showToast({
      title: 'tap...'
    });
  },
  handleShowMask1: function handleShowMask1(e) {
    console.log(e);
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask1: show
    });
  },
  handleShowMask2: function handleShowMask2(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask2: show
    });
  },
  handleShowMask3: function handleShowMask3(e) {
    console.log(e);
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask3: show
    });
  },
  handleShowMask4: function handleShowMask4(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask4: show
    });
  },
  handleShowMask5: function handleShowMask5(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask5: show
    });
  },
  handleShowMask6: function handleShowMask6(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask6: show
    });
  },
  handleShowMask7: function handleShowMask7(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask7: show
    });
  },
  handleShowMask8: function handleShowMask8(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask8: show
    });
  },
  handleShowMask9: function handleShowMask9(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask9: show
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});