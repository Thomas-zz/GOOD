"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// maskTip.js
exports.default = Page({
  data: {
    width: wx.WIN_WIDTH,
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    showMask1: false,
    showMask2: false,
    showMask3: false,
    imgSrc1: 'http://images.uileader.com/20180315/da626bbd-4a86-4d5d-9690-00350528d91f.png',
    imgSrc2: 'http://images.uileader.com/20180315/da626bbd-4a86-4d5d-9690-00350528d91f.png',
    imgSrc3: 'http://images.uileader.com/20180315/f52acb66-d0b2-41fc-be57-30da518e15ec.png',
    customStyle: {
      'background': 'rgba(51, 51, 51, 0.9)'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  handleShowMask1: function handleShowMask1(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask1: show
    });
  },
  handleShowMask2: function handleShowMask2(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask2: show
    });
  },
  handleShowMask3: function handleShowMask3(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask3: show
    });
  }
});