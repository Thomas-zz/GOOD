"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// maskGuide.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    showMask1: true,
    customSyle: {
      'background': 'rgba(0, 0, 0, 0.8)',
      'display': 'flex',
      'align-items': 'center',
      'justify-content': 'center'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  handleShowMask1: function handleShowMask1(e) {
    console.log(e);
    var show = e.currentTarget.dataset.show;
    this.setData({
      showMask1: show
    });
  }
});