"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _data;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// mapDemo.js
// mapDemo02.js
var pathIcon = '/images/path.png';
exports.default = Page({
  data: (_data = {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    latitude: 39.855060,
    longitude: 116.368650,
    scale: 18,
    showLocation: true,
    mapCtx: null,
    polyline: [{
      points: [{
        latitude: 39.853332,
        longitude: 116.371028
      }, {
        latitude: 39.854864,
        longitude: 116.371179
      }, {
        latitude: 39.856289,
        longitude: 116.370293
      }, {
        latitude: 39.855897,
        longitude: 116.368909
      }],
      color: '#ff0000',
      width: 2,
      dottedLine: true
    }],
    controls: [{
      id: 1,
      iconPath: '/images/location.png',
      clickable: true,
      position: {
        left: 15,
        top: 570,
        width: 64,
        height: 64
      }
    }]
  }, _defineProperty(_data, "controls", [{
    id: 1,
    iconPath: '/images/location.png',
    clickable: true,
    position: {
      left: 15,
      top: wx.DEFAULT_CONTENT_HEIGHT - 100,
      width: 64,
      height: 64
    }
  }]), _defineProperty(_data, "circles", [{
    latitude: 39.855060,
    longitude: 116.368650,
    color: '#0000FF33',
    fillColor: '#0000FF33',
    radius: 100,
    strokeWidth: 1

  }]), _data),
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  onReady: function onReady() {
    this.mapCtx = wx.createMapContext('map');
  },
  controltap: function controltap(e) {
    if (e.controlId === 1) {
      this.mapCtx.moveToLocation();
    }
  },
  regionchange: function regionchange() {},
  callouttap: function callouttap(e) {
    if (e.markerId === 2) return;
    if (e.markerId === 1) {
      this.toSysMap(39.855060, 116.368650, '北京引领视觉科技有限公司');
    }
    if (e.markerId === 3) {
      this.toSysMap(39.858620, 116.369580, '右安门翠林小区二里');
    }
  },
  toSysMap: function toSysMap(lat, lng, names) {
    wx.openSysMap({
      latitude: lat,
      longitude: lng,
      name: names,
      success: function success(res) {},
      fail: function fail(res) {},
      complete: function complete(res) {}
    });
  },
  go: function go() {}
});