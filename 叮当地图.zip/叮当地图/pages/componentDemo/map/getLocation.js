"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _amapWx = require("../../../static/map/amap-wx.js");

var _amapWx2 = _interopRequireDefault(_amapWx);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var key = '4216f7d550dc95ef4ac91e3c0ee6a19a';
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    latitude: '',
    longitude: '',
    location: {},
    hasLocation: false,
    textDatas: {}
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  getLocation: function getLocation() {
    var _this = this;

    wx.getLocation({
      type: 'gcj02',
      success: function success(res) {

        _this.setData({
          location: {
            latitude: res.latitude,
            longitude: res.longitude
          },
          longitude: res.longitude,
          latitude: res.latitude,
          hasLocation: true
        });
        _this.getLocalInfo();
      },
      fail: function fail(res) {}
    });
  },
  getLocalInfo: function getLocalInfo() {
    var _this2 = this;

    var myAmapFun = new _amapWx2.default.AMapWX({ key: key });
    myAmapFun.getRegeo({
      location: this.data.longitude + "," + this.data.latitude,
      success: function success(data) {
        console.log(data);
        // 调用成功则将相关数据存储至textData
        _this2.setData({
          textDatas: {
            name: data[0].regeocodeData.formatted_address,
            address: data[0].name,
            latitude: data[0].latitude,
            longitude: data[0].longitude
          }
        });
      },
      fail: function fail(info) {
        console.log(info);
      }
    });
  },
  openLocation: function openLocation() {
    if (!this.data.hasLocation) return;
    wx.openLocation({
      longitude: Number(this.data.longitude),
      latitude: Number(this.data.latitude),
      name: this.data.textDatas.name,
      address: this.data.textDatas.address,
      scale: 16,
      success: function success(data) {
        console.log(data);
      },
      fail: function fail(data) {
        console.log(data);
      }

    });
    // wx.openSysMap({
    //   latitude: Number(this.longitude),
    //   longitude: Number(this.latitude),
    //   name: this.textDatas.name,
    //   success: function(res) {
    //   },
    //   fail: function(res) {
    //   },
    //   complete: function(res) {
    //   }
    // })
  }
});