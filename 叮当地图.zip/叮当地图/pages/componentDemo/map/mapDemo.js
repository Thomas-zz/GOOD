"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _data;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var pathIcon = '/images/path.png';
exports.default = Page({
  data: (_data = {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    latitude: 39.855060,
    longitude: 116.368650,
    scale: 18,
    showLocation: true,
    mapCtx: null,
    markers: [{
      id: 1,
      latitude: 39.855060,
      longitude: 116.368650,
      iconPath: '/images/posi.png',
      label: {
        fontSize: 12,
        color: '#FF0000',
        content: '',
        x: 0.5,
        y: 0.5
      },
      callout: {
        content: '北京引领视觉科技有限公司',
        color: '#000000',
        fontSize: 16,
        bgColor: '#ffffff',
        borderRadius: 10,
        display: 'ALWAYS',
        padding: 6
        // boxShadow: '0 0 1px 1px rgba(0,0,0,.2)'
      },
      width: 30,
      height: 40
    }, {
      id: 2,
      latitude: 39.851297,
      longitude: 116.368175,
      iconPath: '/images/qcsc_ic_location_pin.png',
      label: {
        fontSize: 12,
        color: '#FF0000',
        content: '',
        x: 0.5,
        y: 0.5
      },
      callout: {
        content: "\u5728\u8FD9\u91CC\u4E0A\u8F66",
        color: '#000000',
        fontSize: 16,
        bgColor: '#ffffff',
        borderRadius: 14,
        display: 'ALWAYS',
        padding: 8,
        boxShadow: '0 0 4px 1px rgba(0,0,0,.1)'
      },
      width: 22,
      height: 54
    }, {
      id: 3,
      latitude: 39.858620,
      longitude: 116.369580,
      iconPath: '/images/trip_hotelreuse_map_poi_around_info_stations_selected.png',
      label: {
        content: '点击查看详情',
        fontSize: 12,
        color: '#FF0000'
      },
      callout: {
        content: "\u53F3\u5B89\u95E8\u7FE0\u6797\u5C0F\u533A\u4E8C\u91CC",
        color: '#000000',
        fontSize: 16,
        bgColor: '#ffffff',
        borderRadius: 5,
        display: 'BYCLICK',
        padding: 8,
        boxShadow: '0 0 4px 1px rgba(0,0,0,.1)'
      },
      width: 32,
      height: 45
    }],
    controls: [{
      id: 1,
      iconPath: '/images/location.png',
      clickable: true,
      position: {
        left: 15,
        top: 570,
        width: 64,
        height: 64
      }
    }]
  }, _defineProperty(_data, "controls", [{
    id: 1,
    iconPath: '/images/location.png',
    clickable: true,
    position: {
      left: 15,
      top: wx.DEFAULT_CONTENT_HEIGHT - 100,
      width: 64,
      height: 64
    }
  }]), _defineProperty(_data, "circles", [{
    latitude: 39.855060,
    longitude: 116.368650,
    color: '#0000FF33',
    fillColor: '#0000FF33',
    radius: 100,
    strokeWidth: 1

  }]), _data),

  onReady: function onReady() {
    this.mapCtx = wx.createMapContext('map');
  },
  controltap: function controltap(e) {
    console.log('点击controltap', e);
    if (e.controlId === 1) {
      this.mapCtx.moveToLocation();
    }
  },
  regionchange: function regionchange() {},
  callouttap: function callouttap(e) {
    console.log('callouttap', e);
    // if (e.markerId === 2) return
    // if (e.markerId === 1) {
    //   this.toSysMap(39.855060, 116.368650, '北京引领视觉科技有限公司')
    // }
    // if (e.markerId === 3) {
    //   this.toSysMap(39.858620, 116.369580, '右安门翠林小区二里')
    // }
  },
  toSysMap: function toSysMap(lat, lng, names) {
    wx.openSysMap({
      latitude: lat,
      longitude: lng,
      name: names,
      success: function success(res) {},
      fail: function fail(res) {},
      complete: function complete(res) {}
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});