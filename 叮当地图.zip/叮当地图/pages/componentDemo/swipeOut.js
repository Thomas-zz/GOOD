'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
// slideView.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    list1: [{ height: 80, color: '#FCB300', text: '第37周|总票房8.11亿较上周上涨4.38%，《猩猿崛起》突破票房10亿', switcher: 'off', icon: 'api-access' }, { height: 80, color: '#FF7360', text: '总票房9.60亿较上周 下降30.64%，《战狼2》突破票房10亿', switcher: 'off', icon: 'api-network' }, { height: 80, color: '#39CCC5', text: '本周悬疑《心理罪》、喜剧《鲛珠传》、动作《上船下套》等多部电影在电影院上映。', switcher: 'off', icon: 'api-configure' }, { height: 80, color: '#FCB300', text: '第64周|总票房12亿较上周上涨2.85%，《票吧》突破票房10亿', switcher: 'off', icon: 'api-access' }],
    list2: [{ switcher: 'off', name: '阿强', address: '北京', time: '2010/12/1', buttonText: '删除' }, { switcher: 'off', name: '安生', address: '北京', time: '2010/11/13', buttonText: '删除' }, { switcher: 'off', name: '010-52013145', address: '北京', time: '2010/09/13', buttonText: '删除' }],
    list3: [{ head: 'http://images.uileader.com/20180313/b4af4e36-a677-48b8-9caa-b741582f6c12.png', name: '前端早读课', time: '2017/10/4', img: 'http://images.uileader.com/20180313/9ab8ce19-5a38-4756-9be1-fd598a4dea83.png', text: '【视频】基于Recat Native的跨三端技术实践' }, { head: 'http://images.uileader.com/20180313/be889b2f-7f8e-4e2f-9ae5-2e0bd3d6c85d.png', name: '极乐技术社区', time: '2017/9/5', img: 'http://images.uileader.com/20180313/76d9228c-5779-4416-8f05-2cddb200222a.png', text: '【教程】微信小程序--蓝牙连接开发总结' }, { head: 'http://images.uileader.com/20180313/16224b1e-bd33-482e-bde5-d416723a2970.png', name: '前端人', time: '2017/8/20', img: 'http://images.uileader.com/20180313/41448b31-1f65-4c3d-be58-e7d66601d1c0.png', text: ' 如丝般顺滑：CSS3实现60帧的动画' }],
    el: 'undefined',
    el2: 'undefined'
  },
  del: function del(index) {
    var index = index.target.dataset.idx;
    console.log(index);
    this.data.list1.splice(index, 1);
    console.log(this.data.list1);
    this.setData({
      list1: this.data.list1
    });
    console.log(this.data.list1);
    this.setData({
      el: 'undefined'
    });
  },
  tap: function tap(e) {
    console.log(e);
    wx.showToast({ title: e.currentTarget.dataset.res, icon: 'none' });
  },
  changeHandler1: function changeHandler1(res) {
    console.log(this.data.el);
    var index = res.currentTarget.dataset.index;
    if (this.data.el !== index) {
      if (this.data.el !== 'undefined') {
        this.data.list1[this.data.el].switcher = 'off';
      }
      this.data.list1[index].switcher = 'on';
      this.setData({
        list1: this.data.list1
      });
      this.data.el = index;
    }
  },
  changeHandler2: function changeHandler2(res) {
    var index = res.currentTarget.dataset.index;
    if (this.data.el2 !== index) {
      if (this.data.el2 !== 'undefined') {
        this.data.list2[this.data.el2].switcher = 'off';
      }
      this.data.list2[index].switcher = 'on';
      this.setData({
        list2: this.data.list2
      });
      this.data.el2 = index;
    }
  },
  handletap: function handletap(e) {
    console.log(e);
    wx.showToast({ title: e.target.dataset.res, icon: 'none' });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});