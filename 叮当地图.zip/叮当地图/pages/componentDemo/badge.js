"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    customStyle: {
      'background-color': '#00bc32'
    },
    customStyle2: {
      'background-color': '#fa6e2d',
      'border-radius': '3px',
      'padding': '3px 8px'
    },
    customStyle3: {
      'background-color': '#39f',
      'position': 'absolute',
      'top': '-5px',
      'right': '-15px',
      'border': '1px solid #fff'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});