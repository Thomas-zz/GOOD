"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    activeTabStyle: {
      'color': '#e60012'
    },
    activeTabStyle2: {
      'color': '#e60012',
      'border-bottom': '1px solid #e60012'
    },
    inkBarStyle: {
      'border-bottom': '1px solid red',
      'width': '60%',
      'color': 'red'
    },
    tabStyle: {
      'flex': '0 0 40px'
    },
    current1: 0,
    current2: 0,
    current3: 0,
    current4: 0,
    current5: 0,
    current6: 0,
    current7: 0,
    current8: 0,
    current9: 0,
    current11: 0,
    current12: 0,
    showBadge3: true,
    show8_1: true,
    show8_2: false,
    customStyle: {
      'background-color': 'red'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  handleChange1: function handleChange1(e) {
    console.log(e, 'handleChange1');
    var index = e.detail.index;
    this.setData({
      current1: index
    });
  },
  handleContentChange1: function handleContentChange1(e) {
    var current = e.detail.current;
    this.setData({
      current1: current
    });
  },
  handleChange2: function handleChange2(e) {
    var index = e.detail.index;
    this.setData({
      current2: index
    });
  },
  handleContentChange2: function handleContentChange2(e) {
    var current = e.detail.current;
    this.setData({
      current2: current
    });
  },
  handleChange3: function handleChange3(e) {
    var index = e.detail.index;
    this.setData({
      current3: index
    });
  },
  handleContentChange3: function handleContentChange3(e) {
    var current = e.detail.current;
    this.setData({
      current3: current
    });
  },
  handleChange4: function handleChange4(e) {
    var index = e.detail.index;
    if (index === 1) {
      this.setData({
        showBadge3: false
      });
    }
    this.setData({
      current4: index
    });
  },
  handleContentChange4: function handleContentChange4(e) {
    var current = e.detail.current;
    this.setData({
      current4: current
    });
  },
  handleChange5: function handleChange5(e) {
    var index = e.detail.index;
    this.setData({
      current5: index
    });
  },
  handleContentChange5: function handleContentChange5(e) {
    var current = e.detail.current;
    this.setData({
      current5: current
    });
  },
  handleChange6: function handleChange6(e) {
    var index = e.detail.index;
    this.setData({
      current6: index
    });
  },
  handleContentChange6: function handleContentChange6(e) {
    var current = e.detail.current;
    this.setData({
      current6: current
    });
  },
  handleChange7: function handleChange7(e) {
    var btnIndex = e.target.dataset.index;
    var index = e.detail.index;
    this.data.current7 = index;
    this.setData({
      current7: this.data.current7
    });
    this.setData({
      current7: this.data.current7
    });
  },
  handleChangeBtn7: function handleChangeBtn7(e) {
    var btnIndex = e.target.dataset.index;
    this.data.current7 = btnIndex;
    this.setData({
      current7: this.data.current7
    });
  },
  handleContentChange7: function handleContentChange7(e) {
    var current = e.detail.current;
    this.setData({
      current7: current
    });
  },
  handleChange8: function handleChange8(e) {
    var index = e.detail.index;
    if (index) {
      this.setData({
        show8_1: false,
        show8_2: true
      });
    } else {
      this.setData({
        show8_1: true,
        show8_2: false
      });
    }
  },
  handleChange9: function handleChange9(e) {
    var index = e.detail.index;
    this.setData({
      current9: index
    });
  },
  handleContentChange9: function handleContentChange9(e) {
    var current = e.detail.current;
    this.data.current9 = current;
    this.setData({
      current9: this.data.current9
    });
  },
  handleChange11: function handleChange11(e) {
    var index = e.detail.index;
    this.setData({
      current11: index
    });
  },
  handleContentChange11: function handleContentChange11(e) {
    var current = e.detail.current;
    this.setData({
      current11: current
    });
  },
  hideBadge3: function hideBadge3() {
    this.setData({
      showBadge3: false
    });
  }
});