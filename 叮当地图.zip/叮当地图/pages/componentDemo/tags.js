"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var tagStyle0 = "\n  border: 1px solid #3693E8;\n  background: #ffffff;\n  color: #3693E8;\n  padding: 0 5px;\n  border-radius: 10px;\n  text-align: center;\n  height: 25px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;";

var tagStyle00 = "background: #efefef;\n  color: #555;\n  padding: 0 5px;\n  border-radius: 10px;\n  text-align: center;\n  height: 25px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;\n";

var selectStyle = "background: #54d09f;\n  color: #fff;\n  padding: 0 5px;\n  border-radius: 10px;\n  text-align: center;\n  height: 25px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;\n";

var selectStyle2 = "\n  background: #54d09f;\n  color: #fff;\n  padding: 0 5px;\n  text-align: center;\n  height: 25px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;\n  border-radius: 3px;\n";

var tagStyle1 = "\n  background: #EFEFEF;\n  color: #666;\n  padding: 5px 20px;\n  border-radius: 14px;\n";

var tagStyle2 = "\n  border:1px solid #ccc;\n  background: #fff;\n  color: #666;\n  padding: 0 5px;\n  text-align: center;\n  height: 35px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;\n";

var selectStyle3 = "\n  background: #ffe5de;\n  border:1px solid #ccc;\n  color: #666;\n  padding: 0 5px;\n  text-align: center;\n  height: 35px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;\n";

var tagStyle3 = "\n  background: url('http://images.uileader.com/20180410/e32e7f69-42ea-43f8-ae9d-a666561ba502.png') no-repeat 64px center ;\n  border: 1px solid #ff5800;\n  color: #ff5800;\n  padding: 0 5px;\n  border-radius: 10px;\n  text-align: left;\n  height: 25px;\n  display: flex;\n  width:84px;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;\n  background-size:12px;\n";

var tagStyle6 = "\n  border: 1px solid #f1f2f3;\n  border-radius: 3px;\n  text-align: center;\n  height: 25px;\n  line-height: 24px;\n";

exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    list0: [{
      text: '速度与激情8',
      tagStyle: tagStyle0
    }, {
      text: '铁道飞虎',
      tagStyle: tagStyle0
    }, {
      text: '罗曼蒂克消亡史',
      tagStyle: tagStyle0
    }, {
      text: '绑架者',
      tagStyle: tagStyle0
    }, {
      text: '地心引力',
      tagStyle: tagStyle0
    }, {
      text: '一条狗的使命',
      tagStyle: tagStyle0
    }],
    list00: [{
      text: '速度与激情8',
      tagStyle: tagStyle00,
      tagSelectedStyle: selectStyle,
      checked: true
    }, {
      text: '铁道飞虎',
      tagStyle: tagStyle00,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '罗曼蒂克消亡史',
      tagStyle: tagStyle00,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '绑架者',
      tagStyle: tagStyle00,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '地心引力',
      tagStyle: tagStyle00,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '一条狗的使命',
      tagStyle: tagStyle00,
      tagSelectedStyle: selectStyle,
      checked: false
    }],
    list1: [{
      text: '热门',
      tagStyle: tagStyle1
    }, {
      text: '小吃快餐',
      tagStyle: tagStyle1
    }, {
      text: '面包甜点',
      tagStyle: tagStyle1
    }, {
      text: '北京菜',
      tagStyle: tagStyle1
    }, {
      text: '川菜',
      tagStyle: tagStyle1
    }, {
      text: '韩国料理',
      tagStyle: tagStyle1
    }, {
      text: '江浙菜',
      tagStyle: tagStyle1
    }, {
      text: '江浙菜',
      tagStyle: tagStyle1
    }],

    list2: [{
      text: '微型车',
      tagStyle: tagStyle2,
      tagSelectedStyle: selectStyle3,
      icon: 'plus2',
      iconSelected: 'duigou',
      checked: true
    }, {
      text: '小型车',
      tagStyle: tagStyle2,
      tagSelectedStyle: selectStyle3,
      icon: 'plus2',
      iconSelected: 'duigou',
      checked: true
    }, {
      text: '紧凑型',
      tagStyle: tagStyle2,
      tagSelectedStyle: selectStyle3,
      icon: 'plus2',
      iconSelected: 'duigou',
      checked: false
    }, {
      text: '中型车',
      tagStyle: tagStyle2,
      tagSelectedStyle: selectStyle3,
      icon: 'plus2',
      iconSelected: 'duigou',
      checked: false
    }, {
      text: '大中型',
      tagStyle: tagStyle2,
      tagSelectedStyle: selectStyle3,
      icon: 'plus2',
      iconSelected: 'duigou',
      checked: false
    }, {
      text: '豪华车',
      tagStyle: tagStyle2,
      tagSelectedStyle: selectStyle3,
      icon: 'plus2',
      iconSelected: 'duigou',
      checked: false
    }],

    list3: [{
      text: '大众',
      tagStyle: tagStyle3,
      icon: 'close'
    }, {
      text: '朗逸',
      tagStyle: tagStyle3,
      icon: 'close'
    }, {
      text: '10-15万',
      tagStyle: tagStyle3,
      icon: 'close'
    }],
    list8: [{
      text: '早餐', tagStyle: tagStyle6, tagSelectedStyle: selectStyle2, checked: false
    }, {
      text: '午餐', tagStyle: tagStyle6, tagSelectedStyle: selectStyle2, checked: false
    }, {
      text: '下午茶', tagStyle: tagStyle6, tagSelectedStyle: selectStyle2, checked: false
    }, {
      text: '晚餐', tagStyle: tagStyle6, tagSelectedStyle: selectStyle2, checked: false
    }, {
      text: '夜宵', tagStyle: tagStyle6, tagSelectedStyle: selectStyle2, checked: false
    }],
    fullWidth: false,
    showPop: true,
    selectValue: []
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  singleTap: function singleTap(e) {
    var opt = e.detail.index;
    wx.showToast({
      title: this.data.list00[opt].text,
      icon: 'none'
    });
    this.data.list00.forEach(function (item, index) {
      item.checked = index === opt;
    });
    this.setData({
      list00: this.data.list00
    });
  },
  multipleTap: function multipleTap(e) {
    var opt = e.detail.index;
    this.data.list2[opt].checked = !this.data.list2[opt].checked;
    this.setData({
      list2: this.data.list2
    });
  },
  sure: function sure() {
    var a = this.data.list2.filter(function (item, index) {
      return item.checked;
    });

    this.selectValue = a;
    var str = a.map(function (item, index) {
      return item.text;
    }).join(',');
    this.setData({
      list2: this.data.list2
    });
    wx.showToast({
      title: str || '未选择任何标签',
      icon: 'none'
    });
  },
  cancel: function cancel() {
    this.data.list2.forEach(function (item, index) {
      item.checked = false;
    });
    this.setData({
      list2: this.data.list2
    });
  },
  delate: function delate(e) {
    var opt = e.detail.index;
    this.data.list3 = this.data.list3.filter(function (item, index) {
      return index != opt;
    });
    var str = this.data.list3.map(function (item, index) {
      return item.text;
    }).join(',');
    wx.showToast({
      title: str ? "\u8FD8\u5269\uFF1A" + str : '该组已经没有标签',
      icon: 'none'
    });
    this.setData({
      list3: this.data.list3
    });
  },
  multipleTap2: function multipleTap2(e) {
    var index = e.detail.index;
    this.data.list8[index].checked = !this.data.list8[index].checked;
    this.setData({
      list8: this.data.list8
    });
  }
});