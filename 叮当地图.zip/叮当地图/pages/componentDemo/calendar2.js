"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    statusBarHeight: wx.STATUS_BAR_HEIGHT,
    headerHeight: wx.DEFAULT_HEADER_HEIGHT,
    radioCalendar: false,
    radioDate: '',
    radioMonth: '',
    radioDay: '',
    // 时间对象，存储临时变化的时间
    dateobj: {},
    // 时间可选范围
    monthrange: [],
    // 默认选中的时间范围
    defaultMonthrange: [],
    rangeCalendar: false,
    rangeCalendarDefault: false,
    // 时间差
    differ: '',
    differ2: '2',
    differShow: false,
    rangestart: '',
    rangeend: '',
    rangestart2: '',
    rangeend2: '',
    height: wx.WIN_HEIGHT
  },
  radioinit: function radioinit(thisdate) {
    this.data.dateobj.radioDate = thisdate;
    this.data.dateobj.radioDate = thisdate.split('/');
    this.data.radioDate = this.data.dateobj.radioDate;
    this.data.radioMonth = this.data.dateobj.radioDate[1];
    this.data.radioDay = this.data.dateobj.radioDate[2];
    this.setData({
      radioDate: thisdate,
      radioMonth: this.data.dateobj.radioDate[1],
      radioDay: this.data.dateobj.radioDate[2]
    });
  },
  format: function format(obj) {
    var date = new Date(obj);
    var y = 1900 + date.getYear();
    var m = '0' + (date.getMonth() + 1);
    var d = '0' + date.getDate();
    return y + '/' + m.substring(m.length - 2, m.length) + '/' + d.substring(d.length - 2, d.length);
  },
  radioCalendaropen: function radioCalendaropen() {
    // this.setData({
    //   radioCalendar:true
    // })
    wx.navigateTo({
      url: '/pages/componentDemo/v-calendar3'
    });
  },

  // 双选打开
  rangeCalendaropen: function rangeCalendaropen(state) {
    // this.setData({
    //   rangeCalendar:true
    // })
    wx.navigateTo({
      url: '/pages/componentDemo/v-calendar'
    });
  },
  rangeCalendarDefaultOpen: function rangeCalendarDefaultOpen() {
    wx.navigateTo({
      url: '/pages/componentDemo/v-calendar2'
    });
  },
  onLoad: function onLoad() {
    // 计算时间范围
    var radiodate = new Date();
    var rangedate = new Date();
    var rangedate2 = new Date();
    this.radioDate = this.format(Date.parse(radiodate));
    var start = void 0,
        end = void 0,
        defaultStart = void 0,
        defaultEnd = void 0;
    start = this.format(rangedate.setMonth(new Date().getMonth()));
    end = this.format(rangedate.setMonth(new Date().getMonth() + 6));
    start = start.substring(0, 7);
    end = end.substring(0, 7);
    this.data.monthrange.push(start, end);
    defaultStart = this.format(rangedate2.setDate(new Date().getDate()));
    defaultEnd = this.format(rangedate2.setDate(new Date().getDate() + 2));
    this.data.defaultMonthrange.push(defaultStart, defaultEnd);
    console.log(this.data.defaultMonthrange);

    this.data.rangestart2 = this.data.defaultMonthrange[0];
    this.data.rangeend2 = this.data.defaultMonthrange[1];

    this.setData({
      rangestart2: this.data.rangestart2,
      rangeend2: this.data.rangeend2,
      monthrange: this.data.monthrange,
      defaultMonthrange: this.data.defaultMonthrange
    });
    var date = new Date();
    this.radioinit(this.format(date));
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});