"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    isLoading: false,
    buttonText: '提交',
    isDisable: false,
    hoverStopPropagation: true,
    array: ['美国', '中国', '巴西', '日本'],
    index: 0
  },
  submitHandler: function submitHandler() {
    this.setData({
      isLoading: true,
      buttonText: '提交中...',
      isDisable: true
    });
    // this.isLoading = true
    // this.buttonText = '提交中...'
    // this.isDisable = true
    var that = this;
    setTimeout(function () {
      // that.isLoading = false
      // that.buttonText = '提交'
      // that.isDisable = false
      that.setData({
        isLoading: false,
        buttonText: '提交',
        isDisable: false
      });
    }, 1000);
  },
  handleViewTap: function handleViewTap() {
    wx.showToast({
      title: '点击了ui-view'
    });
  },

  bindPickerChange: function bindPickerChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({
      index: e.detail.value
    });
  },
  handleButtonTap: function handleButtonTap() {
    wx.showToast({
      title: '点击了ui-button'
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});