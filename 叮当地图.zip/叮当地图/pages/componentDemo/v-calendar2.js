"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _data;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.default = Page({
  data: (_data = {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    statusBarHeight: wx.STATUS_BAR_HEIGHT,
    headerHeight: wx.DEFAULT_HEADER_HEIGHT,
    radioCalendar: false,
    radioDate: '',
    radioYear: '',
    radioMonth: '',
    radioDay: '',
    // 时间对象，存储临时变化的时间
    dateobj: {},
    // 时间可选范围
    monthrange: [],
    // 默认选中的时间范围
    defaultMonthrange: [],
    rangeCalendar: false,
    rangeCalendarDefault: false,
    // 时间差
    differ: '',
    differ2: '',
    differShow: false,
    rangeDate: '',
    rangeDate2: '',
    rangestart: '',
    rangeend: '',
    rangestart2: '',
    rangeend2: ''
  }, _defineProperty(_data, "differ2", ''), _defineProperty(_data, "height", wx.WIN_HEIGHT), _data),
  radioinit: function radioinit(thisdate) {
    console.log(thisdate);
    this.data.dateobj.radioDate = thisdate;
    this.data.dateobj.radioDate = thisdate.split('/');
    this.data.radioDate = this.data.dateobj.radioDate;
    this.data.radioMonth = this.data.dateobj.radioDate[1];
    this.data.radioDay = this.data.dateobj.radioDate[2];
    this.setData({
      radioDate: thisdate,
      radioMonth: this.data.dateobj.radioDate[1],
      radioDay: this.data.dateobj.radioDate[2]
    });
    console.log(this.data.radioDate, '11111');
  },

  // 单选将改变的时间，赋值给时间。
  rangeinit: function rangeinit(thisdate) {
    var start = void 0,
        end = void 0;
    this.data.dateobj.rangestart = thisdate.rangedate[0];
    this.data.dateobj.rangeend = thisdate.rangedate[1];
    start = this.data.dateobj.rangestart.split('/');
    end = this.data.dateobj.rangeend.split('/');
    // this.rangestart = `${start[1]}月${start[2]}日`
    // this.rangeend = `${end[1]}月${end[2]}日`
    this.setData({
      rangestart: start[1] + "\u6708" + start[2] + "\u65E5",
      rangeend: end[1] + "\u6708" + end[2] + "\u65E5"
    });
  },
  rangeinit2: function rangeinit2(thisdate) {
    console.log('rangeinit2', thisdate);
    var start = void 0,
        end = void 0;
    this.data.dateobj.rangestart2 = thisdate.rangedate2[0];
    this.data.dateobj.rangeend2 = thisdate.rangedate2[1];
    start = this.data.dateobj.rangestart2.split('/');
    end = this.data.dateobj.rangeend2.split('/');
    // this.rangestart2 = `${start[1]}月${start[2]}日`
    // this.rangeend2 = `${end[1]}月${end[2]}日`
    this.setData({
      rangestart2: start[1] + "\u6708" + start[2] + "\u65E5",
      rangeend2: end[1] + "\u6708" + end[2] + "\u65E5"
    });
    console.log(this.data.rangestart2, this.data.rangeend2, start, end);
  },
  selectedChange: function selectedChange(e) {
    var _this = this;

    this.radioinit(e.detail);
    setTimeout(function () {
      _this.radioCalendar = false;
      _this.setData({
        radioCalendar: false
      });
    }, 200);
  },
  selectedStartHandler: function selectedStartHandler(e) {
    console.log(e, 'selectedStartHandler');
    this.rangeDate = e;
  },
  selectedEndHandler: function selectedEndHandler(e) {
    var _this2 = this;

    console.log(e, 'selectedEndHandler');
    this.data.dateobj.rangedate = e.detail;
    setTimeout(function () {
      // this.rangeCalendar = false
      _this2.setData({
        rangeCalendar: false
      });
      // wx.setStatusBarStyle({style: 'light'})
    }, 200);
    this.calculationDays();
    this.rangeinit(this.data.dateobj);
  },
  failedHandler: function failedHandler(err) {
    if (err === 1) {
      wx.showToast({ title: '您选择的时间超过30天,请重新选择' });
    }
  },
  selectedStartHandler2: function selectedStartHandler2(e) {
    console.log(e, 'selectedStartHandler2开始');
    this.data.rangeDate2 = e.detail;
    console.log(this.data.rangeDate2, 'this.data.rangeDate2');
  },
  selectedEndHandler2: function selectedEndHandler2(e) {
    var _this3 = this;

    console.log(e, 'selectedEndHandler2结束');
    this.data.dateobj.rangedate2 = e.detail;
    console.log(this.data.dateobj.rangedate2);
    setTimeout(function () {
      var pages = getCurrentPages();
      var currPage = pages[pages.length - 1]; //当前页面
      var prevPage = pages[pages.length - 2];
      console.log(_this3.data.dateobj.rangedate2[0], _this3.data.dateobj.rangedate2[1], 'chuanhuiqude');
      _this3.calculationDays2();

      prevPage.setData({
        rangestart2: _this3.data.dateobj.rangedate2[0],
        rangeend2: _this3.data.dateobj.rangedate2[1],
        differ2: _this3.data.differ2
      });
      wx.navigateBack();
    }, 200);
    this.rangeinit2(this.data.dateobj);
  },
  failedHandler2: function failedHandler2(err) {
    if (err === 1) {
      wx.showToast({ title: '您选择的时间超过30天,请重新选择' });
    }
  },
  format: function format(obj) {
    var date = new Date(obj);
    var y = 1900 + date.getYear();
    var m = '0' + (date.getMonth() + 1);
    var d = '0' + date.getDate();
    return y + '/' + m.substring(m.length - 2, m.length) + '/' + d.substring(d.length - 2, d.length);
  },


  // 范围选择，根据选择日期，计算几晚
  calculationDays: function calculationDays() {
    var start = void 0,
        end = void 0;
    start = Date.parse(this.data.dateobj.rangedate[0]);
    end = Date.parse(this.data.dateobj.rangedate[1]);
    this.data.differ = Math.floor((end - start) / (24 * 3600 * 1000));
    this.data.differShow = true;
    this.setData({
      differ: this.data.differ,
      differShow: true
    });
  },

  // 默认选中的。范围选择，根据选择日期，计算几晚
  calculationDays2: function calculationDays2() {
    var start = void 0,
        end = void 0;
    start = Date.parse(this.data.dateobj.rangedate2[0]);
    end = Date.parse(this.data.dateobj.rangedate2[1]);
    this.data.differ2 = Math.floor((end - start) / (24 * 3600 * 1000));
    this.setData({
      differ2: this.data.differ2
    });
  },
  onLoad: function onLoad() {
    // 计算时间范围
    var radiodate = new Date();
    var rangedate = new Date();
    var rangedate2 = new Date();
    this.radioDate = this.format(Date.parse(radiodate));
    var start = void 0,
        end = void 0,
        defaultStart = void 0,
        defaultEnd = void 0;
    start = this.format(rangedate.setMonth(new Date().getMonth()));
    end = this.format(rangedate.setMonth(new Date().getMonth() + 6));
    start = start.substring(0, 7);
    end = end.substring(0, 7);
    this.data.monthrange.push(start, end);
    defaultStart = this.format(rangedate2.setDate(new Date().getDate()));
    defaultEnd = this.format(rangedate2.setDate(new Date().getDate() + 2));
    this.data.defaultMonthrange.push(defaultStart, defaultEnd);
    this.setData({
      monthrange: this.data.monthrange,
      defaultMonthrange: this.data.defaultMonthrange
    });
    var date = new Date();
    this.radioinit(this.format(date));
    console.log(this.data.monthrange, this.data.defaultMonthrange, '12312311');
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});