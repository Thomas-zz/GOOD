"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// showAlert.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px'
  },
  showAlert1: function showAlert1() {
    wx.showAlert({
      title: '开票须知',
      content: '国家税务总局规定：7月1日起，开具增值税普通发票，需提供单位抬头与税号，否者无法用于单位报销；开具增值税专用发票，需提供单位完整信息。请咨询单位财务部门获取相关信息。'
    });
  },
  showAlert2: function showAlert2() {
    wx.showAlert({
      content: '我们团队重视用户隐私并严格遵守相关法律法规的要求。我们对《隐私保护指引》进行了更新，请先阅读内容后再继续使用。',
      confirmText: '了解更多',
      success: function success() {
        wx.showToast({
          title: '触发了解更多'
        });
      }
    });
  },
  showAlert3: function showAlert3() {
    wx.showAlert({
      content: '我们团队重视用户隐私并严格遵守相关法律法规的要求。\r\n我们对《隐私保护指引》进行了更新，请先阅读内容后再继续使用。',
      confirmText: '了解更多'
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});