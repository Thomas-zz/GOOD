"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    url: 'http://images.uileader.com/20180321/ce7dcb1c-5d37-485b-a429-95be5d10edbe.jpg',
    url2: 'http://images.uileader.com/20180321/9d5abf36-1994-41cd-9f0d-e5977379b9fb.jpg'
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});