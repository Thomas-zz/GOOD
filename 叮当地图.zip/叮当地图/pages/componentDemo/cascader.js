"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    poptpTop: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT,
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    height: wx.DEFAULT_CONTENT_HEIGHT,
    show1: false,
    title1: '请选择',
    title2: '请选择',
    title3: '请选择',
    title4: '请选择',
    title5: '请选择',
    show2: false,
    show3: false,
    show4: false,
    show5: false,
    data1: [],
    data2: [{
      name: '美食',
      value: 'food',
      children: [{
        name: '火锅',
        value: 'chafing dish',
        children: [{ name: '川味火锅', value: 'SiChuan chafing dish' }, { name: '老北京火锅', value: 'Beijing chafing dish' }, { name: '牛肉火锅', value: 'Beef chafing dish' }]
      }, {
        name: '西餐',
        value: 'western food',
        children: [{ name: '意大利菜', value: 'Italy food' }, { name: '法国菜', value: 'France food' }, { name: '汉堡', value: 'Hamburg' }]
      }]
    }, {
      name: '旅游',
      value: 'tour',
      children: [{
        name: '周边游',
        value: 'tour around',
        children: [{ name: '景点', value: 'Scenic spot' }, { name: '公园', value: 'Park' }, { name: '名胜古迹', value: 'Historical sites' }]
      }, {
        name: '海外游',
        value: 'tour aboard',
        children: [{ name: '美国游', value: 'American tour' }, { name: '欧洲游', value: 'Europe tour' }, { name: '东南亚游', value: 'Southease Asia tour' }]
      }]
    }],
    data3: [{
      name: '采购部',
      value: 'DP_01',
      children: [{ name: '采购一科', value: 'DP_0101' }, { name: '采购二科', value: 'DP_0102' }, { name: '采购三科', value: 'DP_0103' }]
    }, {
      name: '制造部',
      value: 'DP_02',
      children: [{ name: '制造一科', value: 'DP_0201' }, { name: '制造二科', value: 'DP_0202' }, { name: '制造三科', value: 'DP_0203' }]
    }]
  },
  showPop1: function showPop1() {
    this.setData({
      show1: true
    });
  },
  showPop2: function showPop2() {
    this.setData({
      show2: true
    });
  },
  showPop3: function showPop3() {
    this.setData({
      show3: true
    });
  },
  showPop4: function showPop4() {
    this.setData({
      show4: true
    });
  },
  showPop5: function showPop5() {
    this.setData({
      show5: true
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  handleselected1: function handleselected1(e) {
    var data = e.detail;
    this.data.title1 = "";
    for (var i = 0; i < data.length; i++) {
      this.data.title1 += data[i].name + ' ';
    }
    this.setData({
      show1: false,
      title1: this.data.title1
    });
  },
  handleselected2: function handleselected2(e) {
    var data = e.detail;
    console.log(data);

    this.data.title2 = "";
    for (var i = 0; i < data.length; i++) {
      this.data.title2 += data[i].name + ' ';
    }
    this.setData({
      show2: false,
      title2: this.data.title2
    });
  },
  handleselected3: function handleselected3(e) {
    var data = e.detail;
    this.data.title3 = "";
    for (var i = 0; i < data.length; i++) {
      this.data.title3 += data[i].name + ' ';
    }
    this.setData({
      show3: false,
      title3: this.data.title3
    });
  },
  handleselected4: function handleselected4(e) {
    var data = e.detail;
    this.data.title4 = "";
    for (var i = 0; i < data.length; i++) {
      this.data.title4 += data[i].name + ' ';
    }
    this.setData({
      show4: false,
      title4: this.data.title4
    });
  },
  handleselected5: function handleselected5(e) {
    console.log(e, '121212');
    var data = e.detail;
    this.data.title5 = "";
    for (var i = 0; i < data.length; i++) {
      this.data.title5 += data[i].name + ' ';
    }
    this.setData({
      show5: false,
      title5: this.data.title5
    });
  },

  onReady: function onReady() {
    console.log(this.data.data2);
    this.setData({
      data1: [{
        name: '美食',
        value: 'food',
        children: [{
          name: '火锅',
          value: 'chafing dish',
          children: [{ name: '川味火锅', value: 'SiChuan chafing dish' }, { name: '老北京火锅', value: 'Beijing chafing dish' }, { name: '牛肉火锅', value: 'Beef chafing dish' }]
        }, {
          name: '西餐',
          value: 'western food',
          children: [{ name: '意大利菜', value: 'Italy food' }, { name: '法国菜', value: 'France food' }, { name: '汉堡', value: 'Hamburg' }]
        }]
      }, {
        name: '旅游',
        value: 'tour',
        children: [{
          name: '周边游',
          value: 'tour around',
          children: [{ name: '景点', value: 'Scenic spot' }, { name: '公园', value: 'Park' }, { name: '名胜古迹', value: 'Historical sites' }]
        }, {
          name: '海外游',
          value: 'tour aboard',
          children: [{ name: '美国游', value: 'American tour' }, { name: '欧洲游', value: 'Europe tour' }, { name: '东南亚游', value: 'Southease Asia tour' }]
        }]
      }, {
        name: '旅游',
        value: 'tour',
        children: [{
          name: '周边游',
          value: 'tour around',
          children: [{ name: '景点', value: 'Scenic spot' }, { name: '公园', value: 'Park' }, { name: '名胜古迹', value: 'Historical sites' }]
        }, {
          name: '海外游',
          value: 'tour aboard',
          children: [{ name: '美国游', value: 'American tour' }, { name: '欧洲游', value: 'Europe tour' }, { name: '东南亚游', value: 'Southease Asia tour' }]
        }]
      }, {
        name: '旅游',
        value: 'tour',
        children: [{
          name: '周边游',
          value: 'tour around',
          children: [{ name: '景点', value: 'Scenic spot' }, { name: '公园', value: 'Park' }, { name: '名胜古迹', value: 'Historical sites' }]
        }, {
          name: '海外游',
          value: 'tour aboard',
          children: [{ name: '美国游', value: 'American tour' }, { name: '欧洲游', value: 'Europe tour' }, { name: '东南亚游', value: 'Southease Asia tour' }]
        }]
      }]
    });
  }
});