"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    width: wx.WIN_WIDTH,
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    show: false,
    value1: 0,
    value2: [3, 12],
    value3: 0,
    bufferValue: 0,
    interval: null,
    formatval: null,
    value4: 0,
    max4: 100,
    formatvalue4: null,
    formatmax4: null,
    value5: 1,
    max5: 202,
    formatvalue5: null,
    formatmax5: null,
    value6: [100, 500],
    value7: 0,
    tooltipStyle: {
      'top': '-27px'
    },
    tbObj1: {
      'position': 'absolute',
      'width': '10px',
      'height': '10px',
      'background-color': '#3399FF',
      'border': '0',
      'border-radius': '5px',
      'top': '9px',
      'left': '15px',
      'z-index': '2',
      'box-shadow': '0px 0px 0px'
    },
    tbdObj2: {
      'width': '20px',
      'height': '20px',
      'background-color': '#3399FF',
      'border-radius': '10px',
      'top': '4px',
      'left': '10px'
    },
    tbObj2: {
      'top': '15px',
      'left': '7px',
      'border': '0',
      'width': '15px',
      'height': '20px',
      'border-radius': '0',
      'background-size': '100%',
      'box-shadow': '0px 0px 0px',
      'transform': 'rotate(180deg)',
      'background': 'url(http://images.uileader.com/20180316/e3471aa5-0ca8-413e-a1e7-86bb10dc2533.svg) no-repeat'
    },
    tooltipObj: {
      'font-size': '10px',
      'background-color': '#3399FF',
      'color': 'white',
      'text-align': 'center',
      'width': '28px',
      'height': '16px',
      'line-height': '16px',
      'border-radius': '4px',
      'top': '-7px',
      'left': '0'
    },
    tooltipObj2: {
      'font-size': '10px',
      'background-color': '#ed5565',
      'color': 'white',
      'text-align': 'center',
      'white-space': 'nowrap',
      'width': '50px',
      'height': '18px',
      'line-height': '18px',
      'border-radius': '4px',
      'top': '-15px',
      'left': '-10px'
    },
    tbObj3: {
      'position': 'absolute!important',
      'width': '4px',
      'height': '18px',
      'left': '12.5px',
      'top': '6px',
      'background-color': '#ed5565',
      'border-radius': '2px',
      'border': '0',
      'box-shadow': '0px 0px 0px',
      'z-index': '2'
    },
    tbObj4: {
      'background-image': 'url(http://images.uileader.com/20180417/7bec98d5-4efa-424a-b294-e416da6159bd.png)',
      'background-position': '50% 50%',
      'background-repeat': 'no-repeat',
      'background-color': '#fff',
      'border': '1px solid #ececec',
      'width': '38px',
      'height': '38px',
      'left': '-5px',
      "top": '-6px'
    },
    tbdObj3: {
      'box-shadow': '0px 0px 0px 10px rgba(255,112,0, 0.5)'
    },
    tbObj5: {
      'box-sizing': 'unset',
      'width': '10px',
      'height': '10px',
      'top': '10px!important',
      'left': '15px!important',
      'box-shadow': '0px 0px 0px 5px rgba(255,112,0, 0.5)',
      'background-color': 'rgba(255,112,0, 1)'
    },
    tbObj6: {
      'background-image': 'url(http://images.uileader.com/20180417/7bec98d5-4efa-424a-b294-e416da6159bd.png)',
      'background-position': '50% 50%',
      'background-repeat': 'no-repeat',
      'background-color': '#fff',
      'border': '1px solid #ececec',
      'width': '38px',
      'height': '26px',
      'top': '4px',
      'left': '-6px',
      'border-radius': '5px'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  handletap: function handletap() {
    this.setData({
      show: true
    });
  },
  hidepopup: function hidepopup() {
    this.setData({
      show: false
    });
  },
  hotelHandler: function hotelHandler(e) {
    this.setData({
      value7: e.detail.value
    });
  },
  changeValue: function changeValue() {
    this.setData({
      value1: 80
    });
  },
  sliderchange: function sliderchange(val) {
    console.log(val);
    this.setData({
      value3: val.detail.value
    });
  },
  changeBufferValue: function changeBufferValue() {
    var _this = this;

    this.data.interval = setInterval(function () {
      _this.data.bufferValue += 50;
      _this.setData({
        bufferValue: _this.data.bufferValue
      });

      if (_this.data.bufferValue > 202) {
        // this.data.bufferValue = 202
        _this.setData({
          bufferValue: 202
        });
        clearInterval(_this.data.interval);
      }
    }, 1000);
  },
  getformatval: function getformatval(num) {
    return parseInt(num / 60) + ':' + parseInt((num % 60 >= 10 ? '' : '0') + num % 60);
  },
  slider4: function slider4(val) {
    var value = val.detail.value;
    var value2 = this.getformatval(value);
    this.setData({
      formatvalue4: value2
    });
  },
  slider5: function slider5(val) {
    var value = val.detail.value;
    this.setData({
      formatvalue5: this.getformatval(value)
    });
  },

  onReady: function onReady() {
    this.setData({
      formatvalue4: this.getformatval(this.data.value4)
    });
    this.setData({
      formatmax4: this.getformatval(this.data.max4)
    });
    this.setData({
      formatvalue5: this.getformatval(this.data.value4)
    });
    this.setData({
      formatmax5: this.getformatval(this.data.max4)
    });
  }
});