"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _amapWx = require("../../../static/map/amap-wx.js");

var _amapWx2 = _interopRequireDefault(_amapWx);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var key = '4216f7d550dc95ef4ac91e3c0ee6a19a'; // mapSearchInput.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    text: '定位中…',
    latitude: '',
    longitude: '',
    location: '',
    src: '/images/pos.png'
  },
  fn: function fn() {
    var _this = this;

    wx.getLocation({
      type: 'wgs84',
      success: function success(res) {
        _this.data.location = res.latitude + ',' + res.longitude;
        console.log(_this.data.location, 'location');
      },
      fail: function fail(err) {}
    });
  },
  reserveAddr: function reserveAddr() {
    var _this2 = this;

    console.log(this.data.location);
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?',
      data: {
        location: this.data.location,
        key: 'RHGBZ-S2LAU-5MRV7-4QPTZ-JI25K-HVBDV'
      },
      success: function success(res) {
        console.log(res);
        _this2.setData({
          text: res.data.result.address
        });
      }
    });
  },
  toast: function toast() {
    wx.showToast({ title: '点击“我的位置”按钮测试', icon: 'none' });
  },
  getPosition: function getPosition() {
    var _this3 = this;

    wx.request({
      url: 'https://apis.map.qq.com/ws/location/v1/ip',
      data: {
        key: 'RHGBZ-S2LAU-5MRV7-4QPTZ-JI25K-HVBDV'
      },
      success: function success(res) {
        console.log(res.data.result.ad_info.city);
        // this.text = res.data.result.ad_info.city
        _this3.setData({
          text: res.data.result.ad_info.city
        });
      }
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  onReady: function onReady() {
    this.getPosition();
    this.fn();
  }
});