"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// mapSearchTips.js
var key = '4216f7d550dc95ef4ac91e3c0ee6a19a';
var lonlat;
var city;
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    conHeight: wx.DEFAULT_CONTENT_HEIGHT,
    headerHeight: wx.DEFAULT_HEADER_HEIGHT,
    tips: [],
    tips2: [],
    tips3: [],
    keywords: '',
    tempKeywords: '',
    latitude: 39.855060,
    longitude: 116.368650,
    analogSearch: '',
    show: false,
    show2: false,
    show3: false,
    flag: null,
    markers: []
  },
  callouttap: function callouttap(e) {
    this.toSysMap(39.855060, 116.368650, '北京引领视觉科技有限公司');
  },
  toSysMap: function toSysMap(lat, lng, names) {
    wx.openSysMap({
      latitude: lat,
      longitude: lng,
      name: names,
      success: function success(res) {},
      fail: function fail(res) {},
      complete: function complete(res) {}
    });
  },
  bindhide: function bindhide() {
    // this.show3 = true
    console.log('显示');
    this.setData({
      show3: true
    });
  },
  bindshow: function bindshow() {
    console.log('隐藏');
    // this.show3 = false
    this.setData({
      show3: false
    });
  },
  toggle: function toggle() {
    // this.show2 = true
    this.setData({
      show2: true
    });
  },
  bindtap2: function bindtap2() {
    // this.show2 = true
    this.setData({
      show2: true,
      show: false
    });
    var that = this;
    // this.data.analogSearch = this.data.keywords 
    this.setData({
      analogSearch: this.data.keywords
    });
    wx.request({
      url: 'https://apis.map.qq.com/ws/place/v1/search',
      data: {
        keyword: this.data.keywords,
        boundary: 'region(北京,0)',
        key: 'RHGBZ-S2LAU-5MRV7-4QPTZ-JI25K-HVBDV'
      },
      success: function success(res) {
        // that.data.tips3 = res.data.data
        that.setData({
          tips3: res.data.data
        });
        console.log(that.data.tips3);
      }
    });
  },

  // 输入时请求接口实现联想词
  bindInput: function bindInput(e) {
    console.log(e);
    if (e === undefined) {
      return false;
    }
    this.setData({
      keywords: e.detail.value
    });
    // this.show = true
    this.setData({
      show: true
    });
    var that = this;
    wx.request({
      url: 'https://apis.map.qq.com/ws/place/v1/suggestion',
      data: {
        keyword: this.data.keywords,
        region: '北京',
        key: 'RHGBZ-S2LAU-5MRV7-4QPTZ-JI25K-HVBDV'
      },
      success: function success(res) {
        if (res.data.status === 120) {
          return false;
        } else {
          // that.data.tips = res.data.data
          that.setData({
            tips: res.data.data
          });
        }
      }
    });
  },

  // 点击联想词实现搜索
  associationalSearch: function associationalSearch(e) {
    //获取输入的字符
    console.log(e);
    var data = void 0,
        index = void 0,
        title = void 0,
        flag = void 0;

    if (e.target.dataset.value === undefined) {
      data = e.currentTarget.dataset.value;
      index = e.currentTarget.dataset.index;
      title = e.currentTarget.dataset.title;
      flag = e.currentTarget.dataset.flag;
    } else {
      data = e.target.dataset.value;
      index = e.target.dataset.index;
      title = e.target.dataset.title;
      flag = e.target.dataset.flag;
    }
    var that = this;
    // this.show3 = false
    this.setData({
      show3: false
    });
    var keywords = title;
    console.log(title, keywords);
    if (flag === "0") {
      // this.analogSearch = keywords
      // this.tempKeywords = keywords
      // this.flag = 0
      this.setData({
        analogSearch: keywords,
        tempKeywords: keywords,
        flag: 0
      });
      console.log(this.data.analogSearch, 'this.data.analogSearch');
    } else if (flag === "1") {
      this.flag = 1;
      this.data.tempKeywords = keywords;
      this.setData({
        tempKeywords: keywords,
        flag: 1
      });
    }
    this.latitude = this.data[data][index].location.lat;
    this.longitude = this.data[data][index].location.lng;
    this.setData({
      latitude: this.data[data][index].location.lat,
      longitude: this.data[data][index].location.lng
    });
    var markersSearch = [{
      id: 1,
      latitude: this.data.latitude,
      longitude: this.data.longitude,
      iconPath: '/images/posi.png',
      label: {
        fontSize: 12,
        color: '#FF0000',
        content: '',
        x: 0.5,
        y: 0.5
      },
      callout: {
        content: this.data[data][index].title + "," + this.data[data][index].address,
        color: '#000000',
        fontSize: 16,
        bgColor: '#ffffff',
        borderRadius: 10,
        display: 'ALWAYS',
        padding: 6
      },
      width: 30,
      height: 40
    }];
    console.log(markersSearch);
    // this.data.markers = JSON.parse(JSON.stringify(markersSearch))
    this.setData({
      markers: JSON.parse(JSON.stringify(markersSearch))
    });

    console.log(this.data.markers);

    // this.show = false
    // this.show2= false

    // this[data] = []

    // this.tips = []
    // this.tips2 = []

    this.setData({
      show: false,
      show2: false,
      tips: [],
      tips2: []
    });
    // console.log()
  },

  // 点击搜索按钮或小键盘上搜索实现搜索
  bindtap: function bindtap() {
    this.show = false;
    console.log(this.show);
    this.show2 = true;
    var that = this;
    wx.request({
      url: 'http://apis.map.qq.com/ws/place/v1/suggestion',
      data: {
        keyword: this.keywords,
        region: '北京',
        key: 'RHGBZ-S2LAU-5MRV7-4QPTZ-JI25K-HVBDV'
      },
      success: function success(res) {
        console.log(res.data.data);
        that.tips2 = res.data.data;
      }
    });
  },
  bindfocus: function bindfocus() {
    this.show = true;
    console.log('huodejiaodian');
    this.bindInput();
  },
  bindblur: function bindblur() {
    this.show = false;
    console.log(this.show);
  },
  searchShow: function searchShow() {
    console.log('searchShow');
    // this.show = true
    this.setData({
      show: true
    });
    if (this.data.flag === 0) {
      // this.keywords = this.tempKeywords
      this.setData({
        keywords: this.data.tempKeywords
      });
    } else if (this.data.flag === 1) {
      return false;
    }
  }
});