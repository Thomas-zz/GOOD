"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// grid-img.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px'
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});