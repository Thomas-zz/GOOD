"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var tagStyle = "\n  color: #555;\n  padding: 0 20rpx;\n  border-radius: 3px;\n  text-align: center;\n  height: 25px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;\n  margin: 14rpx 0;\n  border:1px solid #ccc;\n";
var selectStyle = "\n  padding: 0 20rpx;\n  border-radius: 3px;\n  text-align: center;\n  height: 25px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  line-height: 20px;\n  margin: 14rpx 0;\n  background: #F2E8E7;\n  color: #ED3027;\n  border:1px solid #ccc;\n";
// popup.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    show: false,
    show1: false,
    show2: false,
    show3: false,
    show4: false,
    show5: false,
    show6: false,
    show7: false,
    show8: false,
    tagsWidth: wx.WIN_WIDTH - 20,
    poptpTop: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT,
    maskStyle1: {
      'background-color': 'transparent'
    },
    maskStyle2: {
      'top': '198px'
    },
    list00: [{
      text: '全部活动',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: true
    }, {
      text: '电脑办公',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '精选活动',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '个护美妆',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '家用电器',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '酒水饮料',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '日用百货',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '流行服饰',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '鞋靴箱包',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '手机数码',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }, {
      text: '钟表珠宝',
      tagStyle: tagStyle,
      tagSelectedStyle: selectStyle,
      checked: false
    }]
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  log: function log(str) {
    if (str === 'hide') {
      this.show1 = false;
    }
  },
  handleShow2: function handleShow2() {
    this.setData({
      show2: false
    });
  },
  bindinit: function bindinit(e) {
    console.log('bindinit');
  },
  bindshow: function bindshow() {
    console.log('bindshow');
  },
  handleShow3: function handleShow3() {
    this.setData({
      show3: false
    });
  },
  handleShow4: function handleShow4() {
    this.setData({
      show4: false
    });
  },
  handleShow5: function handleShow5() {
    this.setData({
      show5: false
    });
  },
  singleTap: function singleTap(e) {
    var opt = e.detail.index;
    wx.showToast({
      title: this.data.list00[opt].text,
      icon: 'none'
    });
    // this.data.show7 = false
    this.data.list00.forEach(function (item, index) {
      item.checked = index === opt;
    });
    this.setData({
      show7: false,
      list00: this.data.list00
    });
  },
  openPopup1: function openPopup1(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      show1: show
    });
  },
  openPopup2: function openPopup2(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      show2: show
    });
  },
  openPopup3: function openPopup3(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      show3: show
    });
  },
  openPopup4: function openPopup4(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      show4: show
    });
  },
  openPopup5: function openPopup5(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      show5: show
    });
  },
  openPopup6: function openPopup6(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      show6: show
    });
  },
  openPopup7: function openPopup7(e) {
    var show = e.currentTarget.dataset.show;
    this.setData({
      show7: show
    });
  },
  openPopup8: function openPopup8(e) {
    var _this = this;

    var show = e.currentTarget.dataset.show;
    this.setData({
      show8: show
    });
    setTimeout(function () {
      _this.setData({
        show8: false
      });
    }, 2000);
  },
  handleSwitchChange: function handleSwitchChange(e) {
    this.setData({
      show1: e.detail.value
    });
  }
});