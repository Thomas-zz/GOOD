"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    numberStyle: {
      color: '#1DA1D2',
      fontSize: '30px',
      letterSpacing: '18px',
      zIndex: '2',
      position: 'absolute',
      left: '18px',
      top: '10px'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});