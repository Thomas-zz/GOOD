"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// constant.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    isAPP: '',
    isAndroid: '',
    isIOS: '',
    winHeight: '',
    statusBarHright: '',
    defaultHeaderHeight: '',
    defaultContentHright: '',
    winWidth: ''
  },
  onReady: function onReady() {
    this.setData({
      isAPP: wx.IS_APP,
      isAndroid: wx.IS_ANDROID,
      isIOS: wx.IS_IOS,
      winHeight: wx.WIN_HEIGHT,
      statusBarHright: wx.STATUS_BAR_HEIGHT,
      defaultHeaderHeight: wx.DEFAULT_HEADER_HEIGHT,
      defaultContentHright: wx.DEFAULT_CONTENT_HEIGHT,
      winWidth: wx.WIN_WIDTH
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});