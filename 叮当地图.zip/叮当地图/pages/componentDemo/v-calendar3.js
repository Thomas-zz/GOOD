"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    radioDate: '',
    radioMonth: '',
    radioDay: '',
    // 时间对象，存储临时变化的时间
    dateobj: {},
    // 时间可选范围
    monthrange: [],
    // 默认选中的时间范围
    defaultMonthrange: [],
    rangeCalendar: false,
    rangeCalendarDefault: false,
    // 时间差
    differ: '',
    differ2: '',
    differShow: false,
    rangeDate: '',
    rangeDate2: '',
    rangestart: '',
    rangeend: '',
    rangestart2: '',
    rangeend2: '',
    height: wx.WIN_HEIGHT
  },
  radioinit: function radioinit(thisdate) {
    this.data.dateobj.radioDate = thisdate;
    this.data.dateobj.radioDate = thisdate.split('/');
    this.data.radioDate = this.data.dateobj.radioDate;
    this.data.radioMonth = this.data.dateobj.radioDate[1];
    this.data.radioDay = this.data.dateobj.radioDate[2];
    this.setData({
      radioDate: thisdate
    });
  },
  selectedChange: function selectedChange(e) {
    var _this = this;

    this.radioinit(e.detail);
    setTimeout(function () {
      var pages = getCurrentPages();
      var currPage = pages[pages.length - 1]; //当前页面
      var prevPage = pages[pages.length - 2];
      console.log(_this.data.dateobj.radioDate, 'chuanhuiqude');
      prevPage.setData({
        radioMonth: _this.data.dateobj.radioDate[1],
        radioDay: _this.data.dateobj.radioDate[2]
      });
      wx.navigateBack();
    }, 200);
  },
  format: function format(obj) {
    var date = new Date(obj);
    var y = 1900 + date.getYear();
    var m = '0' + (date.getMonth() + 1);
    var d = '0' + date.getDate();
    return y + '/' + m.substring(m.length - 2, m.length) + '/' + d.substring(d.length - 2, d.length);
  },
  onLoad: function onLoad() {
    // 计算时间范围
    var radiodate = new Date();
    var rangedate2 = new Date();

    var date = new Date();
    this.radioinit(this.format(date));
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});