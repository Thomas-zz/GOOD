"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    value: 1,
    contentshow: 1,
    contentshow2: 0,
    tabContent: ['内容一', '内容二', '内容三'],
    itemStyle: {
      'height': '25px',
      'color': '#333',
      'border-color': '#333',
      'background': 'transparent',
      'line-height': '25px',
      'font-size': '12px',
      'width': '77px'
    },
    activeItemStyle: {
      'opacity': '1',
      'color': '#fff',
      'background-color': '#333'
    }
  },
  handleChange: function handleChange(e) {
    console.log(e.detail.index);
    var index = e.detail.index;
    wx.showToast({
      title: 'index: ' + index,
      icon: 'none'
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  changeTab1: function changeTab1(e) {
    var index = e.detail.index;
    this.setData({
      contentshow: index
    });
  },
  changeTab2: function changeTab2(e) {
    var index = e.detail.index;
    this.setData({
      contentshow2: index
    });
  }
});