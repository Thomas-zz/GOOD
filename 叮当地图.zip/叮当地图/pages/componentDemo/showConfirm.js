"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// showConfirm.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px'
  },
  showConfirm1: function showConfirm1() {
    wx.showConfirm({
      content: '您尚未绑定银行卡，绑定银行卡后即可向商家付款',
      cancelColor: 'red',
      confirmColor: '#3399ff',
      confirmText: '去绑卡',
      cancelText: '返回'
    });
  },
  showConfirm2: function showConfirm2() {
    wx.showConfirm({
      title: '提示',
      content: '您尚未绑定银行卡，绑定银行卡后即可向商家付款',
      cancelColor: '#e60012',
      confirmColor: '#3399ff',
      confirmText: '去绑卡',
      cancelText: '返回'
    });
  },
  showConfirm3: function showConfirm3() {
    wx.showConfirm({
      title: '提示',
      content: '您尚未绑定银行卡\r\n绑定银行卡后即可向商家付款',
      cancelColor: 'red',
      confirmColor: '#3399ff',
      confirmText: '去绑卡',
      cancelText: '返回',
      success: function success(res) {
        if (res) {
          wx.showToast({
            title: '触发去绑卡按钮'
          });
        }
      }
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});