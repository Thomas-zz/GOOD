"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _Page;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.default = Page((_Page = {
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    date: '',
    dateDay: '',
    dateObj: {},
    dataMonth: ''
  },
  selectedHandler: function selectedHandler(e) {
    console.log(e, 'selectedHandlerselectedHandler');
    var val = e.detail;
    console.log(val);
    this.data.dateObj = val.split('/');
    this.data.dateDay = this.data.dateObj[0] + "\u5E74" + this.data.dateObj[1] + "\u6708" + this.data.dateObj[2] + "\u65E5";
    this.setData({
      dateObj: this.data.dateObj,
      dateDay: this.data.dateDay
    });
  },
  weekHandler: function weekHandler(e) {
    console.log(e, 'weekHandler');
    var dataMonth = e.detail.substring(0, 7);
    dataMonth = dataMonth.split('/');
    console.log(dataMonth);
    this.data.dataMonth = dataMonth[0] + "\u5E74" + dataMonth[1] + "\u6708";
    console.log(this.data.dataMonth);
    this.setData({
      dataMonth: this.data.dataMonth
    });
  },
  navigateBack: function navigateBack() {
    ui.navigateBack();
  },
  format: function format(obj) {
    var date = new Date(obj);
    var y = 1900 + date.getYear();
    var m = '0' + (date.getMonth() + 1);
    var d = '0' + date.getDate();
    return y + '/' + m.substring(m.length - 2, m.length) + '/' + d.substring(d.length - 2, d.length);
  }
}, _defineProperty(_Page, "navigateBack", function navigateBack() {
  wx.navigateBack();
}), _defineProperty(_Page, "onLoad", function onLoad() {
  var date = new Date();
  date = Date.parse(date);
  date = this.format(date);
  this.data.date = date;
  this.data.dateObj = this.data.date.split('/');
  this.data.dateDay = this.data.dateObj[0] + "\u5E74" + this.data.dateObj[1] + "\u6708" + this.data.dateObj[2] + "\u65E5";
  this.data.dataMonth = this.data.dateObj[0] + "\u5E74" + this.data.dateObj[1] + "\u6708";
  this.setData({
    date: date,
    dateObj: this.data.dateObj,
    dateDay: this.data.dateDay,
    dataMonth: this.data.dataMonth
  });
}), _Page));