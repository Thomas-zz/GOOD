"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// stepper.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px'
  },
  subtraction: function subtraction(e) {
    console.log(e);
    var val = e.detail.toString();
    console.log(val);
    wx.showToast({ title: val, icon: 'none' });
  },
  addition: function addition(e) {
    console.log(e);
    var val = e.detail.toString();
    console.log(val);
    wx.showToast({ title: val, icon: 'none' });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});