"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// segment2.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    contentshow: 0,
    items0: [],
    items1: [],
    setShow: false,
    itemStyle: {
      'border-color': '#0dc1ae',
      'color': '#0dc1ae',
      'font-size': '14px'
    },
    activeItemStyle: {
      'color': '#fff',
      'background-color': '#0dc1ae'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  handleNavRight: function handleNavRight() {
    wx.showActionSheet({
      itemList: ['转账记录', '使用帮助', '延时转账服务'],
      success: function success(index) {
        wx.showToast({
          title: "index: " + index
        });
      }
    });
  },
  changTab: function changTab(e) {
    var index = e.detail.index;
    this.setData({
      contentshow: index
    });
    // if (index === 0) {
    //   this.setShow = false
    //   this.setData({
    //     setShow:false
    //   })
    // } else {
    //   this.setData({
    //     setShow:true
    //   })
    // }
  },

  onReady: function onReady() {
    var arr = [];
    var arr2 = [];
    for (var i = 1; i <= 30; i++) {
      arr.push(" - \u63A8\u8350\u5217\u8868\u9879\u76EE" + i);
    }
    for (var _i = 1; _i <= 30; _i++) {
      arr2.push(" - \u70ED\u70B9\u5217\u8868\u9879\u76EE" + _i);
    }
    this.setData({
      items0: arr,
      items1: arr2
    });
  }
});