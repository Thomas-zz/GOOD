"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// ruler.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    valueStyle: {
      color: '#F6620F',
      fontSize: '28px',
      top: '-54px',
      borderBottom: '1px dashed #E0E0E0',
      padding: '0 10px',
      left: '50%',
      transform: 'translate(-50%, 0%)'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});