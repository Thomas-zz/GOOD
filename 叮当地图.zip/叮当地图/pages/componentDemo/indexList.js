"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// indexList.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    country1: '北京',
    country2: '宝马',
    country3: '阿强',
    currency: '澳元(OPM)'
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  showIndexList1: function showIndexList1() {
    wx.navigateTo({
      url: "/pages/componentDemo/indexList1?country=" + this.data.country1
    });
  },
  showIndexList4: function showIndexList4() {
    wx.navigateTo({
      url: '/pages/componentDemo/indexList4'
    });
  }
});