"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var items = [];
for (var i = 1; i <= 30; i++) {
  items.push("\u5217\u8868\u9879\u76EE" + i);
}
exports.default = Page({
  data: {
    items: items,
    index: 0,
    scrollTop: 0,
    width: wx.WIN_WIDTH,
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  handleChange: function handleChange(e) {
    console.log(e);
    var index = e.detail.index;
    this.setData({
      index: index
    });
  },
  onPageScroll: function onPageScroll(e) {
    console.log(e);
    this.setData({
      scrollTop: e.scrollTop
    });
  }
});