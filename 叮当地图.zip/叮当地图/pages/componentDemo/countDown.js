"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
// countDown.js
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    numberStyle: {
      backgroundColor: '#4c4c4c',
      color: '#fff',
      paddingLeft: '4px',
      paddingRight: '4px',
      marginLeft: '8px',
      marginRight: '8px',
      borderRadius: '4px',
      fontSize: '12px',
      minWidth: '30px',
      display: 'inline-block',
      textAlign: 'center',
      lineHeight: '20px'
    }
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  bindtimeup: function bindtimeup() {
    wx.showToast({ title: '倒计时结束', icon: 'none' });
  }
});