"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    headerHeight: wx.DEFAULT_HEADER_HEIGHT,
    radioDate: '',
    radioMonth: '',
    radioDay: '',
    // 时间对象，存储临时变化的时间
    dateobj: {},
    // 时间可选范围
    monthrange: [],
    // 默认选中的时间范围
    defaultMonthrange: [],
    rangeDate: '',
    rangestart: '',
    rangeend: '',
    height: wx.WIN_HEIGHT,
    differ: ''
  },
  radioinit: function radioinit(thisdate) {

    this.data.dateobj.radioDate = thisdate;
    this.data.dateobj.radioDate = thisdate.split('/');
    this.data.radioDate = this.data.dateobj.radioDate;
    this.data.radioMonth = this.data.dateobj.radioDate[1];
    this.data.radioDay = this.data.dateobj.radioDate[2];
    this.setData({
      radioDate: thisdate,
      radioMonth: this.data.dateobj.radioDate[1],
      radioDay: this.data.dateobj.radioDate[2]
    });
  },

  // 单选将改变的时间，赋值给时间。
  rangeinit: function rangeinit(thisdate) {
    var start = void 0,
        end = void 0;
    this.data.dateobj.rangestart = thisdate.rangedate[0];
    this.data.dateobj.rangeend = thisdate.rangedate[1];
    start = this.data.dateobj.rangestart.split('/');
    end = this.data.dateobj.rangeend.split('/');
    // this.rangestart = `${start[1]}月${start[2]}日`
    // this.rangeend = `${end[1]}月${end[2]}日`
    this.setData({
      rangestart: start[1] + "\u6708" + start[2] + "\u65E5",
      rangeend: end[1] + "\u6708" + end[2] + "\u65E5"
    });
  },


  // 范围选择，根据选择日期，计算几晚
  calculationDays: function calculationDays() {
    var start = void 0,
        end = void 0;
    start = Date.parse(this.data.dateobj.rangedate[0]);
    end = Date.parse(this.data.dateobj.rangedate[1]);
    this.data.differ = Math.floor((end - start) / (24 * 3600 * 1000));
    this.data.differShow = true;
    this.setData({
      differ: this.data.differ,
      differShow: true
    });
  },
  selectedStartHandler: function selectedStartHandler(e) {

    this.rangeDate = e;
  },
  selectedEndHandler: function selectedEndHandler(e) {
    var _this = this;

    this.data.dateobj.rangedate = e.detail;
    setTimeout(function () {
      var pages = getCurrentPages();
      var currPage = pages[pages.length - 1]; //当前页面
      var prevPage = pages[pages.length - 2];
      console.log(_this.data.dateobj.rangedate[0], _this.data.dateobj.rangedate[1], 'chuanhuiqude');
      _this.calculationDays();
      prevPage.setData({
        rangestart: _this.data.dateobj.rangedate[0],
        rangeend: _this.data.dateobj.rangedate[1],
        differ: _this.data.differ
      });
      wx.navigateBack();
    }, 500);
    this.rangeinit(this.data.dateobj);
  },
  failedHandler: function failedHandler(err) {
    if (err === 1) {
      wx.showToast({ title: '您选择的时间超过30天,请重新选择' });
    }
  },
  format: function format(obj) {
    var date = new Date(obj);
    var y = 1900 + date.getYear();
    var m = '0' + (date.getMonth() + 1);
    var d = '0' + date.getDate();
    return y + '/' + m.substring(m.length - 2, m.length) + '/' + d.substring(d.length - 2, d.length);
  },
  onLoad: function onLoad() {
    // 计算时间范围
    var rangedate = new Date();
    var rangedate2 = new Date();
    var start = void 0,
        end = void 0;
    start = this.format(rangedate.setMonth(new Date().getMonth()));
    end = this.format(rangedate.setMonth(new Date().getMonth() + 6));
    start = start.substring(0, 7);
    end = end.substring(0, 7);
    this.data.monthrange.push(start, end);
    this.setData({
      monthrange: this.data.monthrange
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});