'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _demo = require('./demo.js');

var _demo2 = _interopRequireDefault(_demo);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = Page({
  onLoad: function onLoad() {
    var _this = this;

    var obj = JSON.parse(_demo2.default.result);
    console.log(obj);
    var objIndex = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    objIndex.forEach(function (item, index) {
      if (obj[item].length > 0) {
        var content = {
          index: item,
          items: obj[item]
        };
        _this.data.list.push(content);
      }
    });

    console.log(this.data.list, '123');
    this.setData({
      list: this.data.list
    });
  },

  data: {
    conHeight: wx.DEFAULT_CONTENT_HEIGHT,
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    list: []

  },
  tapHandler: function tapHandler(msg) {
    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1]; //当前页面
    var prevPage = pages[pages.length - 2];
    prevPage.setData({
      currency: msg.detail.name
    });
    wx.navigateBack();
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
});