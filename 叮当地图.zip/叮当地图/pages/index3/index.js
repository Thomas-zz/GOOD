// pages/index3/index.js
Page({

  data: {
    region: '选择省/市/区',
    now: ''
  },
  selected: function (e) {
    this.setData({
      region: e.detail.value
    })
    this.getWeather();
  },
  getWeather: function () {
    var that = this;
    wx.request({
      url: 'https://free-api.heweather.net/s6/weather/now?',
      data: {
        location: that.data.region[1],
        key: '61ec926d11314a7099ac83de4e2c5d29'
      },
      success: function (res) {
        console.log(location)
        console.log(res.data)
        console.log(res.data.HeWeather6[0].now)
        that.setData({ now: res.data.HeWeather6[0].now })
      }
    })
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  }
})