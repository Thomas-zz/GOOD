'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Page({
  data: {
    NAV_HEIGHT: wx.STATUS_BAR_HEIGHT + wx.DEFAULT_HEADER_HEIGHT + 'px',
    delay: {
      delay: 3000
    },
    imgHeight: parseInt(wx.WIN_WIDTH / 750 * 312),
    alpha: 0,
    bottom: 30,
    className: '',
    statusHeight: wx.STATUS_BAR_HEIGHT,
    isSplashSwiper: false,
    // 轮播
    items: [{
      src: 'http://images.uileader.com/20180408/eef1a709-72d8-45e4-a62c-a887a1685576.jpg',
      url: '/pages/templeteDemo/O2O/O2O'
    }, { src: 'http://images.uileader.com/20180408/8e90e7ef-ef87-4668-ad70-d9dff30145be.jpg',
      url: '/pages/templeteDemo/graphic/graphic'
    }, { src: 'http://images.uileader.com/20180408/01fda88d-8b55-405f-bc78-1e091607be64.jpg',
      url: '/pages/templeteDemo/form/payment'
    }, { src: 'http://images.uileader.com/20180408/e9a11567-8cbf-4a66-b486-4ddb0b10ab31.jpg',
      url: '/pages/templeteDemo/dataReport/fundOptional'
    }]
  },
  navigateTo: function navigateTo(index) {
    wx.navigateTo({
      url: this.items[index].url
    });
  },
  handlePullRefresh: function handlePullRefresh() {
    wx.showToast({
      title: '处理下拉刷新'
    });
  },
  handleBegin: function handleBegin(_ref) {
    var distance = _ref.distance,
        direction = _ref.direction;

    if (distance > 10) {
      this.className = 'opacity';
    }
  },
  handleAfter: function handleAfter() {
    this.className = 'opacity opacity1';
  },
  splashInto: function splashInto() {
    this.isSplashSwiper = false;
    wx.setStorageSync('splash', 'show');
  },
  changeSwiper: function changeSwiper(e) {},
  onShareAppMessage: function onShareAppMessage() {}
});